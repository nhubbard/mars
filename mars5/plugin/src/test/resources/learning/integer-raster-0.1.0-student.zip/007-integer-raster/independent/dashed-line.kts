// Generated public raster checks; regenerate with tools/raster_lesson_cases.py.
// Byte strings encode the book environment’s little-endian words.

case("dashed 1,1 to 6,4", instructionLimit = 10000) {
    setBytes("frame", 0, 0, 0, 90, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    setBytes("endpoints", 1, 0, 0, 0, 1, 0, 0, 0, 6, 0, 0, 0, 4, 0, 0, 0)
    setBytes("color", 255, 255, 255, 0)
    setBytes("line_count", 0, 0, 0, 107)
    setBytes("frame_guard", 120, 86, 52, 18)
    setBytes("endpoints_guard", 121, 86, 52, 18)
    setBytes("color_guard", 122, 86, 52, 18)
    setBytes("count_guard", 123, 86, 52, 18)
    setRegister("s0", 0x1122334400000000uL.toLong())
    setRegister("s1", 0x1122334401010101uL.toLong())
    setRegister("s2", 0x1122334402020202uL.toLong())
    setRegister("s3", 0x1122334403030303uL.toLong())
    setRegister("s4", 0x1122334404040404uL.toLong())
    setRegister("s5", 0x1122334405050505uL.toLong())
    setRegister("s6", 0x1122334406060606uL.toLong())
    setRegister("s7", 0x1122334407070707uL.toLong())
    setRegister("fp", 0x1020304005060708uL.toLong())
    setRegister("gp", 0x0102030450607080uL.toLong())
    setRegister("sp", 0x000000007fffeffcuL.toLong())
    val top = readRegister("sp") and -16L
    setRegister("sp", top)
    val saved = listOf("s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "fp", "gp").associateWith(::readRegister)
    val callerBytes = readBytes(top, 32)
    val protected = listOf(
        traceMemoryStores("endpoints", 16),
        traceMemoryStores("color", 4),
        traceMemoryStores("frame_guard", 4),
        traceMemoryStores("endpoints_guard", 4),
        traceMemoryStores("color_guard", 4),
        traceMemoryStores("count_guard", 4),
    )
    setRegisterToDataAddress("a0", "endpoints")
    setRegisterToDataAddress("a1", "frame")
    setRegister("a2", 0x0000000000000000uL.toLong())
    callFunction("draw_dashed", returnTo = "line_complete")
    expectRegister("v0", 3)
    expectBytes("frame", 0, 0, 0, 90, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 0, 0, 0, 0, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 0, 0, 0, 0, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 0, 0, 0, 0, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    expectBytes("endpoints", 1, 0, 0, 0, 1, 0, 0, 0, 6, 0, 0, 0, 4, 0, 0, 0)
    expectBytes("color", 255, 255, 255, 0)
    expectBytes("line_count", 0, 0, 0, 107)
    expectBytes("frame_guard", 120, 86, 52, 18)
    expectBytes("endpoints_guard", 121, 86, 52, 18)
    expectBytes("color_guard", 122, 86, 52, 18)
    expectBytes("count_guard", 123, 86, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (register, value) -> expectRegister(register, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
    setRegisterToDataAddress("a0", "endpoints")
    setRegisterToDataAddress("a1", "frame")
    setRegister("a2", 0x0000000000000000uL.toLong())
    callFunction("draw_dashed", returnTo = "line_repeat")
    expectRegister("v0", 3)
    expectBytes("frame", 0, 0, 0, 90, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 0, 0, 0, 0, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 0, 0, 0, 0, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 0, 0, 0, 0, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    expectBytes("endpoints", 1, 0, 0, 0, 1, 0, 0, 0, 6, 0, 0, 0, 4, 0, 0, 0)
    expectBytes("color", 255, 255, 255, 0)
    expectBytes("line_count", 0, 0, 0, 107)
    expectBytes("frame_guard", 120, 86, 52, 18)
    expectBytes("endpoints_guard", 121, 86, 52, 18)
    expectBytes("color_guard", 122, 86, 52, 18)
    expectBytes("count_guard", 123, 86, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (register, value) -> expectRegister(register, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
}

case("dashed 6,4 to 1,1", instructionLimit = 10000) {
    setBytes("frame", 0, 0, 0, 90, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    setBytes("endpoints", 6, 0, 0, 0, 4, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0)
    setBytes("color", 241, 249, 253, 0)
    setBytes("line_count", 1, 0, 0, 107)
    setBytes("frame_guard", 103, 86, 52, 18)
    setBytes("endpoints_guard", 88, 86, 52, 18)
    setBytes("color_guard", 89, 86, 52, 18)
    setBytes("count_guard", 90, 86, 52, 18)
    setRegister("s0", 0x1122334401010101uL.toLong())
    setRegister("s1", 0x1122334402020202uL.toLong())
    setRegister("s2", 0x1122334403030303uL.toLong())
    setRegister("s3", 0x1122334404040404uL.toLong())
    setRegister("s4", 0x1122334405050505uL.toLong())
    setRegister("s5", 0x1122334406060606uL.toLong())
    setRegister("s6", 0x1122334407070707uL.toLong())
    setRegister("s7", 0x1122334408080808uL.toLong())
    setRegister("fp", 0x1020304004070609uL.toLong())
    setRegister("gp", 0x0102030451617181uL.toLong())
    setRegister("sp", 0x000000007fffdffcuL.toLong())
    val top = readRegister("sp") and -16L
    setRegister("sp", top)
    val saved = listOf("s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "fp", "gp").associateWith(::readRegister)
    val callerBytes = readBytes(top, 32)
    val protected = listOf(
        traceMemoryStores("endpoints", 16),
        traceMemoryStores("color", 4),
        traceMemoryStores("frame_guard", 4),
        traceMemoryStores("endpoints_guard", 4),
        traceMemoryStores("color_guard", 4),
        traceMemoryStores("count_guard", 4),
    )
    setRegisterToDataAddress("a0", "endpoints")
    setRegisterToDataAddress("a1", "frame")
    setRegister("a2", 0x000000000002060euL.toLong())
    callFunction("draw_dashed", returnTo = "line_complete")
    expectRegister("v0", 3)
    expectBytes("frame", 0, 0, 0, 90, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 14, 6, 2, 0, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 14, 6, 2, 0, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 14, 6, 2, 0, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    expectBytes("endpoints", 6, 0, 0, 0, 4, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0)
    expectBytes("color", 241, 249, 253, 0)
    expectBytes("line_count", 1, 0, 0, 107)
    expectBytes("frame_guard", 103, 86, 52, 18)
    expectBytes("endpoints_guard", 88, 86, 52, 18)
    expectBytes("color_guard", 89, 86, 52, 18)
    expectBytes("count_guard", 90, 86, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (register, value) -> expectRegister(register, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
    setRegisterToDataAddress("a0", "endpoints")
    setRegisterToDataAddress("a1", "frame")
    setRegister("a2", 0x000000000002060euL.toLong())
    callFunction("draw_dashed", returnTo = "line_repeat")
    expectRegister("v0", 3)
    expectBytes("frame", 0, 0, 0, 90, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 14, 6, 2, 0, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 14, 6, 2, 0, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 14, 6, 2, 0, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    expectBytes("endpoints", 6, 0, 0, 0, 4, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0)
    expectBytes("color", 241, 249, 253, 0)
    expectBytes("line_count", 1, 0, 0, 107)
    expectBytes("frame_guard", 103, 86, 52, 18)
    expectBytes("endpoints_guard", 88, 86, 52, 18)
    expectBytes("color_guard", 89, 86, 52, 18)
    expectBytes("count_guard", 90, 86, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (register, value) -> expectRegister(register, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
}

case("dashed 0,0 to 2,1", instructionLimit = 10000) {
    setBytes("frame", 0, 0, 0, 90, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    setBytes("endpoints", 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 1, 0, 0, 0)
    setBytes("color", 234, 246, 252, 0)
    setBytes("line_count", 2, 0, 0, 107)
    setBytes("frame_guard", 70, 86, 52, 18)
    setBytes("endpoints_guard", 71, 86, 52, 18)
    setBytes("color_guard", 56, 86, 52, 18)
    setBytes("count_guard", 57, 86, 52, 18)
    setRegister("s0", 0x1122334402020202uL.toLong())
    setRegister("s1", 0x1122334403030303uL.toLong())
    setRegister("s2", 0x1122334404040404uL.toLong())
    setRegister("s3", 0x1122334405050505uL.toLong())
    setRegister("s4", 0x1122334406060606uL.toLong())
    setRegister("s5", 0x1122334407070707uL.toLong())
    setRegister("s6", 0x1122334408080808uL.toLong())
    setRegister("s7", 0x1122334409090909uL.toLong())
    setRegister("fp", 0x102030400704050auL.toLong())
    setRegister("gp", 0x0102030452627282uL.toLong())
    setRegister("sp", 0x000000007fffcffcuL.toLong())
    val top = readRegister("sp") and -16L
    setRegister("sp", top)
    val saved = listOf("s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "fp", "gp").associateWith(::readRegister)
    val callerBytes = readBytes(top, 32)
    val protected = listOf(
        traceMemoryStores("endpoints", 16),
        traceMemoryStores("color", 4),
        traceMemoryStores("frame_guard", 4),
        traceMemoryStores("endpoints_guard", 4),
        traceMemoryStores("color_guard", 4),
        traceMemoryStores("count_guard", 4),
    )
    setRegisterToDataAddress("a0", "endpoints")
    setRegisterToDataAddress("a1", "frame")
    setRegister("a2", 0x0000000000030915uL.toLong())
    callFunction("draw_dashed", returnTo = "line_complete")
    expectRegister("v0", 2)
    expectBytes("frame", 21, 9, 3, 0, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 21, 9, 3, 0, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    expectBytes("endpoints", 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 1, 0, 0, 0)
    expectBytes("color", 234, 246, 252, 0)
    expectBytes("line_count", 2, 0, 0, 107)
    expectBytes("frame_guard", 70, 86, 52, 18)
    expectBytes("endpoints_guard", 71, 86, 52, 18)
    expectBytes("color_guard", 56, 86, 52, 18)
    expectBytes("count_guard", 57, 86, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (register, value) -> expectRegister(register, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
    setRegisterToDataAddress("a0", "endpoints")
    setRegisterToDataAddress("a1", "frame")
    setRegister("a2", 0x0000000000030915uL.toLong())
    callFunction("draw_dashed", returnTo = "line_repeat")
    expectRegister("v0", 2)
    expectBytes("frame", 21, 9, 3, 0, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 21, 9, 3, 0, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    expectBytes("endpoints", 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 1, 0, 0, 0)
    expectBytes("color", 234, 246, 252, 0)
    expectBytes("line_count", 2, 0, 0, 107)
    expectBytes("frame_guard", 70, 86, 52, 18)
    expectBytes("endpoints_guard", 71, 86, 52, 18)
    expectBytes("color_guard", 56, 86, 52, 18)
    expectBytes("count_guard", 57, 86, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (register, value) -> expectRegister(register, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
}

case("dashed 2,1 to 0,0", instructionLimit = 10000) {
    setBytes("frame", 0, 0, 0, 90, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    setBytes("endpoints", 2, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    setBytes("color", 227, 243, 251, 0)
    setBytes("line_count", 3, 0, 0, 107)
    setBytes("frame_guard", 37, 86, 52, 18)
    setBytes("endpoints_guard", 38, 86, 52, 18)
    setBytes("color_guard", 39, 86, 52, 18)
    setBytes("count_guard", 24, 86, 52, 18)
    setRegister("s0", 0x1122334403030303uL.toLong())
    setRegister("s1", 0x1122334404040404uL.toLong())
    setRegister("s2", 0x1122334405050505uL.toLong())
    setRegister("s3", 0x1122334406060606uL.toLong())
    setRegister("s4", 0x1122334407070707uL.toLong())
    setRegister("s5", 0x1122334408080808uL.toLong())
    setRegister("s6", 0x1122334409090909uL.toLong())
    setRegister("s7", 0x112233440a0a0a0auL.toLong())
    setRegister("fp", 0x102030400605040buL.toLong())
    setRegister("gp", 0x0102030453637383uL.toLong())
    setRegister("sp", 0x000000007fffbffcuL.toLong())
    val top = readRegister("sp") and -16L
    setRegister("sp", top)
    val saved = listOf("s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "fp", "gp").associateWith(::readRegister)
    val callerBytes = readBytes(top, 32)
    val protected = listOf(
        traceMemoryStores("endpoints", 16),
        traceMemoryStores("color", 4),
        traceMemoryStores("frame_guard", 4),
        traceMemoryStores("endpoints_guard", 4),
        traceMemoryStores("color_guard", 4),
        traceMemoryStores("count_guard", 4),
    )
    setRegisterToDataAddress("a0", "endpoints")
    setRegisterToDataAddress("a1", "frame")
    setRegister("a2", 0x0000000000040c1cuL.toLong())
    callFunction("draw_dashed", returnTo = "line_complete")
    expectRegister("v0", 2)
    expectBytes("frame", 28, 12, 4, 0, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 28, 12, 4, 0, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    expectBytes("endpoints", 2, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("color", 227, 243, 251, 0)
    expectBytes("line_count", 3, 0, 0, 107)
    expectBytes("frame_guard", 37, 86, 52, 18)
    expectBytes("endpoints_guard", 38, 86, 52, 18)
    expectBytes("color_guard", 39, 86, 52, 18)
    expectBytes("count_guard", 24, 86, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (register, value) -> expectRegister(register, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
    setRegisterToDataAddress("a0", "endpoints")
    setRegisterToDataAddress("a1", "frame")
    setRegister("a2", 0x0000000000040c1cuL.toLong())
    callFunction("draw_dashed", returnTo = "line_repeat")
    expectRegister("v0", 2)
    expectBytes("frame", 28, 12, 4, 0, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 28, 12, 4, 0, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    expectBytes("endpoints", 2, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("color", 227, 243, 251, 0)
    expectBytes("line_count", 3, 0, 0, 107)
    expectBytes("frame_guard", 37, 86, 52, 18)
    expectBytes("endpoints_guard", 38, 86, 52, 18)
    expectBytes("color_guard", 39, 86, 52, 18)
    expectBytes("count_guard", 24, 86, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (register, value) -> expectRegister(register, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
}

case("dashed 3,7 to 3,0", instructionLimit = 10000) {
    setBytes("frame", 0, 0, 0, 90, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    setBytes("endpoints", 3, 0, 0, 0, 7, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0)
    setBytes("color", 220, 240, 250, 0)
    setBytes("line_count", 4, 0, 0, 107)
    setBytes("frame_guard", 4, 86, 52, 18)
    setBytes("endpoints_guard", 5, 86, 52, 18)
    setBytes("color_guard", 6, 86, 52, 18)
    setBytes("count_guard", 7, 86, 52, 18)
    setRegister("s0", 0x1122334404040404uL.toLong())
    setRegister("s1", 0x1122334405050505uL.toLong())
    setRegister("s2", 0x1122334406060606uL.toLong())
    setRegister("s3", 0x1122334407070707uL.toLong())
    setRegister("s4", 0x1122334408080808uL.toLong())
    setRegister("s5", 0x1122334409090909uL.toLong())
    setRegister("s6", 0x112233440a0a0a0auL.toLong())
    setRegister("s7", 0x112233440b0b0b0buL.toLong())
    setRegister("fp", 0x102030400102030cuL.toLong())
    setRegister("gp", 0x0102030454647484uL.toLong())
    setRegister("sp", 0x000000007fffaffcuL.toLong())
    val top = readRegister("sp") and -16L
    setRegister("sp", top)
    val saved = listOf("s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "fp", "gp").associateWith(::readRegister)
    val callerBytes = readBytes(top, 32)
    val protected = listOf(
        traceMemoryStores("endpoints", 16),
        traceMemoryStores("color", 4),
        traceMemoryStores("frame_guard", 4),
        traceMemoryStores("endpoints_guard", 4),
        traceMemoryStores("color_guard", 4),
        traceMemoryStores("count_guard", 4),
    )
    setRegisterToDataAddress("a0", "endpoints")
    setRegisterToDataAddress("a1", "frame")
    setRegister("a2", 0x0000000000050f23uL.toLong())
    callFunction("draw_dashed", returnTo = "line_complete")
    expectRegister("v0", 4)
    expectBytes("frame", 0, 0, 0, 90, 3, 1, 1, 90, 6, 2, 2, 90, 35, 15, 5, 0, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 35, 15, 5, 0, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 35, 15, 5, 0, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 35, 15, 5, 0, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    expectBytes("endpoints", 3, 0, 0, 0, 7, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("color", 220, 240, 250, 0)
    expectBytes("line_count", 4, 0, 0, 107)
    expectBytes("frame_guard", 4, 86, 52, 18)
    expectBytes("endpoints_guard", 5, 86, 52, 18)
    expectBytes("color_guard", 6, 86, 52, 18)
    expectBytes("count_guard", 7, 86, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (register, value) -> expectRegister(register, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
    setRegisterToDataAddress("a0", "endpoints")
    setRegisterToDataAddress("a1", "frame")
    setRegister("a2", 0x0000000000050f23uL.toLong())
    callFunction("draw_dashed", returnTo = "line_repeat")
    expectRegister("v0", 4)
    expectBytes("frame", 0, 0, 0, 90, 3, 1, 1, 90, 6, 2, 2, 90, 35, 15, 5, 0, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 35, 15, 5, 0, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 35, 15, 5, 0, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 35, 15, 5, 0, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    expectBytes("endpoints", 3, 0, 0, 0, 7, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("color", 220, 240, 250, 0)
    expectBytes("line_count", 4, 0, 0, 107)
    expectBytes("frame_guard", 4, 86, 52, 18)
    expectBytes("endpoints_guard", 5, 86, 52, 18)
    expectBytes("color_guard", 6, 86, 52, 18)
    expectBytes("count_guard", 7, 86, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (register, value) -> expectRegister(register, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
}

case("dashed 4,4 to 4,4", instructionLimit = 10000) {
    setBytes("frame", 0, 0, 0, 90, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    setBytes("endpoints", 4, 0, 0, 0, 4, 0, 0, 0, 4, 0, 0, 0, 4, 0, 0, 0)
    setBytes("color", 213, 237, 249, 0)
    setBytes("line_count", 5, 0, 0, 107)
    setBytes("frame_guard", 227, 86, 52, 18)
    setBytes("endpoints_guard", 228, 86, 52, 18)
    setBytes("color_guard", 229, 86, 52, 18)
    setBytes("count_guard", 230, 86, 52, 18)
    setRegister("s0", 0x1122334405050505uL.toLong())
    setRegister("s1", 0x1122334406060606uL.toLong())
    setRegister("s2", 0x1122334407070707uL.toLong())
    setRegister("s3", 0x1122334408080808uL.toLong())
    setRegister("s4", 0x1122334409090909uL.toLong())
    setRegister("s5", 0x112233440a0a0a0auL.toLong())
    setRegister("s6", 0x112233440b0b0b0buL.toLong())
    setRegister("s7", 0x112233440c0c0c0cuL.toLong())
    setRegister("fp", 0x102030400003020duL.toLong())
    setRegister("gp", 0x0102030455657585uL.toLong())
    setRegister("sp", 0x000000007fff9ffcuL.toLong())
    val top = readRegister("sp") and -16L
    setRegister("sp", top)
    val saved = listOf("s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "fp", "gp").associateWith(::readRegister)
    val callerBytes = readBytes(top, 32)
    val protected = listOf(
        traceMemoryStores("endpoints", 16),
        traceMemoryStores("color", 4),
        traceMemoryStores("frame_guard", 4),
        traceMemoryStores("endpoints_guard", 4),
        traceMemoryStores("color_guard", 4),
        traceMemoryStores("count_guard", 4),
    )
    setRegisterToDataAddress("a0", "endpoints")
    setRegisterToDataAddress("a1", "frame")
    setRegister("a2", 0x000000000006122auL.toLong())
    callFunction("draw_dashed", returnTo = "line_complete")
    expectRegister("v0", 1)
    expectBytes("frame", 0, 0, 0, 90, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 42, 18, 6, 0, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    expectBytes("endpoints", 4, 0, 0, 0, 4, 0, 0, 0, 4, 0, 0, 0, 4, 0, 0, 0)
    expectBytes("color", 213, 237, 249, 0)
    expectBytes("line_count", 5, 0, 0, 107)
    expectBytes("frame_guard", 227, 86, 52, 18)
    expectBytes("endpoints_guard", 228, 86, 52, 18)
    expectBytes("color_guard", 229, 86, 52, 18)
    expectBytes("count_guard", 230, 86, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (register, value) -> expectRegister(register, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
    setRegisterToDataAddress("a0", "endpoints")
    setRegisterToDataAddress("a1", "frame")
    setRegister("a2", 0x000000000006122auL.toLong())
    callFunction("draw_dashed", returnTo = "line_repeat")
    expectRegister("v0", 1)
    expectBytes("frame", 0, 0, 0, 90, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 42, 18, 6, 0, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    expectBytes("endpoints", 4, 0, 0, 0, 4, 0, 0, 0, 4, 0, 0, 0, 4, 0, 0, 0)
    expectBytes("color", 213, 237, 249, 0)
    expectBytes("line_count", 5, 0, 0, 107)
    expectBytes("frame_guard", 227, 86, 52, 18)
    expectBytes("endpoints_guard", 228, 86, 52, 18)
    expectBytes("color_guard", 229, 86, 52, 18)
    expectBytes("count_guard", 230, 86, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (register, value) -> expectRegister(register, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
}

case("dashed 1,6 to 3,0", instructionLimit = 10000) {
    setBytes("frame", 0, 0, 0, 90, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    setBytes("endpoints", 1, 0, 0, 0, 6, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0)
    setBytes("color", 206, 234, 248, 0)
    setBytes("line_count", 6, 0, 0, 107)
    setBytes("frame_guard", 194, 86, 52, 18)
    setBytes("endpoints_guard", 195, 86, 52, 18)
    setBytes("color_guard", 196, 86, 52, 18)
    setBytes("count_guard", 197, 86, 52, 18)
    setRegister("s0", 0x1122334406060606uL.toLong())
    setRegister("s1", 0x1122334407070707uL.toLong())
    setRegister("s2", 0x1122334408080808uL.toLong())
    setRegister("s3", 0x1122334409090909uL.toLong())
    setRegister("s4", 0x112233440a0a0a0auL.toLong())
    setRegister("s5", 0x112233440b0b0b0buL.toLong())
    setRegister("s6", 0x112233440c0c0c0cuL.toLong())
    setRegister("s7", 0x112233440d0d0d0duL.toLong())
    setRegister("fp", 0x102030400300010euL.toLong())
    setRegister("gp", 0x0102030456667686uL.toLong())
    setRegister("sp", 0x000000007fff8ffcuL.toLong())
    val top = readRegister("sp") and -16L
    setRegister("sp", top)
    val saved = listOf("s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "fp", "gp").associateWith(::readRegister)
    val callerBytes = readBytes(top, 32)
    val protected = listOf(
        traceMemoryStores("endpoints", 16),
        traceMemoryStores("color", 4),
        traceMemoryStores("frame_guard", 4),
        traceMemoryStores("endpoints_guard", 4),
        traceMemoryStores("color_guard", 4),
        traceMemoryStores("count_guard", 4),
    )
    setRegisterToDataAddress("a0", "endpoints")
    setRegisterToDataAddress("a1", "frame")
    setRegister("a2", 0x0000000000071531uL.toLong())
    callFunction("draw_dashed", returnTo = "line_complete")
    expectRegister("v0", 4)
    expectBytes("frame", 0, 0, 0, 90, 3, 1, 1, 90, 6, 2, 2, 90, 49, 21, 7, 0, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 49, 21, 7, 0, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 49, 21, 7, 0, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 49, 21, 7, 0, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    expectBytes("endpoints", 1, 0, 0, 0, 6, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("color", 206, 234, 248, 0)
    expectBytes("line_count", 6, 0, 0, 107)
    expectBytes("frame_guard", 194, 86, 52, 18)
    expectBytes("endpoints_guard", 195, 86, 52, 18)
    expectBytes("color_guard", 196, 86, 52, 18)
    expectBytes("count_guard", 197, 86, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (register, value) -> expectRegister(register, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
    setRegisterToDataAddress("a0", "endpoints")
    setRegisterToDataAddress("a1", "frame")
    setRegister("a2", 0x0000000000071531uL.toLong())
    callFunction("draw_dashed", returnTo = "line_repeat")
    expectRegister("v0", 4)
    expectBytes("frame", 0, 0, 0, 90, 3, 1, 1, 90, 6, 2, 2, 90, 49, 21, 7, 0, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 49, 21, 7, 0, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 49, 21, 7, 0, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 49, 21, 7, 0, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    expectBytes("endpoints", 1, 0, 0, 0, 6, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("color", 206, 234, 248, 0)
    expectBytes("line_count", 6, 0, 0, 107)
    expectBytes("frame_guard", 194, 86, 52, 18)
    expectBytes("endpoints_guard", 195, 86, 52, 18)
    expectBytes("color_guard", 196, 86, 52, 18)
    expectBytes("count_guard", 197, 86, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (register, value) -> expectRegister(register, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
}

case("dashed 0,7 to 7,7", instructionLimit = 10000) {
    setBytes("frame", 0, 0, 0, 90, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    setBytes("endpoints", 0, 0, 0, 0, 7, 0, 0, 0, 7, 0, 0, 0, 7, 0, 0, 0)
    setBytes("color", 199, 231, 247, 0)
    setBytes("line_count", 7, 0, 0, 107)
    setBytes("frame_guard", 161, 86, 52, 18)
    setBytes("endpoints_guard", 162, 86, 52, 18)
    setBytes("color_guard", 163, 86, 52, 18)
    setBytes("count_guard", 164, 86, 52, 18)
    setRegister("s0", 0x1122334407070707uL.toLong())
    setRegister("s1", 0x1122334408080808uL.toLong())
    setRegister("s2", 0x1122334409090909uL.toLong())
    setRegister("s3", 0x112233440a0a0a0auL.toLong())
    setRegister("s4", 0x112233440b0b0b0buL.toLong())
    setRegister("s5", 0x112233440c0c0c0cuL.toLong())
    setRegister("s6", 0x112233440d0d0d0duL.toLong())
    setRegister("s7", 0x112233440e0e0e0euL.toLong())
    setRegister("fp", 0x102030400201000fuL.toLong())
    setRegister("gp", 0x0102030457677787uL.toLong())
    setRegister("sp", 0x000000007fff7ffcuL.toLong())
    val top = readRegister("sp") and -16L
    setRegister("sp", top)
    val saved = listOf("s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "fp", "gp").associateWith(::readRegister)
    val callerBytes = readBytes(top, 32)
    val protected = listOf(
        traceMemoryStores("endpoints", 16),
        traceMemoryStores("color", 4),
        traceMemoryStores("frame_guard", 4),
        traceMemoryStores("endpoints_guard", 4),
        traceMemoryStores("color_guard", 4),
        traceMemoryStores("count_guard", 4),
    )
    setRegisterToDataAddress("a0", "endpoints")
    setRegisterToDataAddress("a1", "frame")
    setRegister("a2", 0x0000000000081838uL.toLong())
    callFunction("draw_dashed", returnTo = "line_complete")
    expectRegister("v0", 4)
    expectBytes("frame", 0, 0, 0, 90, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 56, 24, 8, 0, 171, 57, 57, 90, 56, 24, 8, 0, 177, 59, 59, 90, 56, 24, 8, 0, 183, 61, 61, 90, 56, 24, 8, 0, 189, 63, 63, 90)
    expectBytes("endpoints", 0, 0, 0, 0, 7, 0, 0, 0, 7, 0, 0, 0, 7, 0, 0, 0)
    expectBytes("color", 199, 231, 247, 0)
    expectBytes("line_count", 7, 0, 0, 107)
    expectBytes("frame_guard", 161, 86, 52, 18)
    expectBytes("endpoints_guard", 162, 86, 52, 18)
    expectBytes("color_guard", 163, 86, 52, 18)
    expectBytes("count_guard", 164, 86, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (register, value) -> expectRegister(register, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
    setRegisterToDataAddress("a0", "endpoints")
    setRegisterToDataAddress("a1", "frame")
    setRegister("a2", 0x0000000000081838uL.toLong())
    callFunction("draw_dashed", returnTo = "line_repeat")
    expectRegister("v0", 4)
    expectBytes("frame", 0, 0, 0, 90, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 56, 24, 8, 0, 171, 57, 57, 90, 56, 24, 8, 0, 177, 59, 59, 90, 56, 24, 8, 0, 183, 61, 61, 90, 56, 24, 8, 0, 189, 63, 63, 90)
    expectBytes("endpoints", 0, 0, 0, 0, 7, 0, 0, 0, 7, 0, 0, 0, 7, 0, 0, 0)
    expectBytes("color", 199, 231, 247, 0)
    expectBytes("line_count", 7, 0, 0, 107)
    expectBytes("frame_guard", 161, 86, 52, 18)
    expectBytes("endpoints_guard", 162, 86, 52, 18)
    expectBytes("color_guard", 163, 86, 52, 18)
    expectBytes("count_guard", 164, 86, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (register, value) -> expectRegister(register, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
}

case("dashed 0,0 to 7,7", instructionLimit = 10000) {
    setBytes("frame", 0, 0, 0, 90, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    setBytes("endpoints", 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 0, 7, 0, 0, 0)
    setBytes("color", 192, 228, 246, 0)
    setBytes("line_count", 8, 0, 0, 107)
    setBytes("frame_guard", 128, 86, 52, 18)
    setBytes("endpoints_guard", 129, 86, 52, 18)
    setBytes("color_guard", 130, 86, 52, 18)
    setBytes("count_guard", 131, 86, 52, 18)
    setRegister("s0", 0x1122334408080808uL.toLong())
    setRegister("s1", 0x1122334409090909uL.toLong())
    setRegister("s2", 0x112233440a0a0a0auL.toLong())
    setRegister("s3", 0x112233440b0b0b0buL.toLong())
    setRegister("s4", 0x112233440c0c0c0cuL.toLong())
    setRegister("s5", 0x112233440d0d0d0duL.toLong())
    setRegister("s6", 0x112233440e0e0e0euL.toLong())
    setRegister("s7", 0x112233440f0f0f0fuL.toLong())
    setRegister("fp", 0x102030400d0e0f00uL.toLong())
    setRegister("gp", 0x0102030458687888uL.toLong())
    setRegister("sp", 0x000000007fff6ffcuL.toLong())
    val top = readRegister("sp") and -16L
    setRegister("sp", top)
    val saved = listOf("s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "fp", "gp").associateWith(::readRegister)
    val callerBytes = readBytes(top, 32)
    val protected = listOf(
        traceMemoryStores("endpoints", 16),
        traceMemoryStores("color", 4),
        traceMemoryStores("frame_guard", 4),
        traceMemoryStores("endpoints_guard", 4),
        traceMemoryStores("color_guard", 4),
        traceMemoryStores("count_guard", 4),
    )
    setRegisterToDataAddress("a0", "endpoints")
    setRegisterToDataAddress("a1", "frame")
    setRegister("a2", 0x0000000000091b3fuL.toLong())
    callFunction("draw_dashed", returnTo = "line_complete")
    expectRegister("v0", 4)
    expectBytes("frame", 63, 27, 9, 0, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 63, 27, 9, 0, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 63, 27, 9, 0, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 63, 27, 9, 0, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    expectBytes("endpoints", 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 0, 7, 0, 0, 0)
    expectBytes("color", 192, 228, 246, 0)
    expectBytes("line_count", 8, 0, 0, 107)
    expectBytes("frame_guard", 128, 86, 52, 18)
    expectBytes("endpoints_guard", 129, 86, 52, 18)
    expectBytes("color_guard", 130, 86, 52, 18)
    expectBytes("count_guard", 131, 86, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (register, value) -> expectRegister(register, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
    setRegisterToDataAddress("a0", "endpoints")
    setRegisterToDataAddress("a1", "frame")
    setRegister("a2", 0x0000000000091b3fuL.toLong())
    callFunction("draw_dashed", returnTo = "line_repeat")
    expectRegister("v0", 4)
    expectBytes("frame", 63, 27, 9, 0, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 63, 27, 9, 0, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 63, 27, 9, 0, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 63, 27, 9, 0, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    expectBytes("endpoints", 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 0, 7, 0, 0, 0)
    expectBytes("color", 192, 228, 246, 0)
    expectBytes("line_count", 8, 0, 0, 107)
    expectBytes("frame_guard", 128, 86, 52, 18)
    expectBytes("endpoints_guard", 129, 86, 52, 18)
    expectBytes("color_guard", 130, 86, 52, 18)
    expectBytes("count_guard", 131, 86, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (register, value) -> expectRegister(register, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
}

case("dashed 7,0 to 0,7", instructionLimit = 10000) {
    setBytes("frame", 0, 0, 0, 90, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    setBytes("endpoints", 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 0)
    setBytes("color", 185, 225, 245, 0)
    setBytes("line_count", 9, 0, 0, 107)
    setBytes("frame_guard", 111, 87, 52, 18)
    setBytes("endpoints_guard", 96, 87, 52, 18)
    setBytes("color_guard", 97, 87, 52, 18)
    setBytes("count_guard", 98, 87, 52, 18)
    setRegister("s0", 0x1122334409090909uL.toLong())
    setRegister("s1", 0x112233440a0a0a0auL.toLong())
    setRegister("s2", 0x112233440b0b0b0buL.toLong())
    setRegister("s3", 0x112233440c0c0c0cuL.toLong())
    setRegister("s4", 0x112233440d0d0d0duL.toLong())
    setRegister("s5", 0x112233440e0e0e0euL.toLong())
    setRegister("s6", 0x112233440f0f0f0fuL.toLong())
    setRegister("s7", 0x1122334410101010uL.toLong())
    setRegister("fp", 0x102030400c0f0e01uL.toLong())
    setRegister("gp", 0x0102030459697989uL.toLong())
    setRegister("sp", 0x000000007fff5ffcuL.toLong())
    val top = readRegister("sp") and -16L
    setRegister("sp", top)
    val saved = listOf("s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "fp", "gp").associateWith(::readRegister)
    val callerBytes = readBytes(top, 32)
    val protected = listOf(
        traceMemoryStores("endpoints", 16),
        traceMemoryStores("color", 4),
        traceMemoryStores("frame_guard", 4),
        traceMemoryStores("endpoints_guard", 4),
        traceMemoryStores("color_guard", 4),
        traceMemoryStores("count_guard", 4),
    )
    setRegisterToDataAddress("a0", "endpoints")
    setRegisterToDataAddress("a1", "frame")
    setRegister("a2", 0x00000000000a1e46uL.toLong())
    callFunction("draw_dashed", returnTo = "line_complete")
    expectRegister("v0", 4)
    expectBytes("frame", 0, 0, 0, 90, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 70, 30, 10, 0, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 70, 30, 10, 0, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 70, 30, 10, 0, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 70, 30, 10, 0, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    expectBytes("endpoints", 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 0)
    expectBytes("color", 185, 225, 245, 0)
    expectBytes("line_count", 9, 0, 0, 107)
    expectBytes("frame_guard", 111, 87, 52, 18)
    expectBytes("endpoints_guard", 96, 87, 52, 18)
    expectBytes("color_guard", 97, 87, 52, 18)
    expectBytes("count_guard", 98, 87, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (register, value) -> expectRegister(register, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
    setRegisterToDataAddress("a0", "endpoints")
    setRegisterToDataAddress("a1", "frame")
    setRegister("a2", 0x00000000000a1e46uL.toLong())
    callFunction("draw_dashed", returnTo = "line_repeat")
    expectRegister("v0", 4)
    expectBytes("frame", 0, 0, 0, 90, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 70, 30, 10, 0, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 70, 30, 10, 0, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 70, 30, 10, 0, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 70, 30, 10, 0, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    expectBytes("endpoints", 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 0)
    expectBytes("color", 185, 225, 245, 0)
    expectBytes("line_count", 9, 0, 0, 107)
    expectBytes("frame_guard", 111, 87, 52, 18)
    expectBytes("endpoints_guard", 96, 87, 52, 18)
    expectBytes("color_guard", 97, 87, 52, 18)
    expectBytes("count_guard", 98, 87, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (register, value) -> expectRegister(register, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
}

case("dashed 0,0 to 1,2", instructionLimit = 10000) {
    setBytes("frame", 0, 0, 0, 90, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    setBytes("endpoints", 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 2, 0, 0, 0)
    setBytes("color", 178, 222, 244, 0)
    setBytes("line_count", 10, 0, 0, 107)
    setBytes("frame_guard", 78, 87, 52, 18)
    setBytes("endpoints_guard", 79, 87, 52, 18)
    setBytes("color_guard", 64, 87, 52, 18)
    setBytes("count_guard", 65, 87, 52, 18)
    setRegister("s0", 0x112233440a0a0a0auL.toLong())
    setRegister("s1", 0x112233440b0b0b0buL.toLong())
    setRegister("s2", 0x112233440c0c0c0cuL.toLong())
    setRegister("s3", 0x112233440d0d0d0duL.toLong())
    setRegister("s4", 0x112233440e0e0e0euL.toLong())
    setRegister("s5", 0x112233440f0f0f0fuL.toLong())
    setRegister("s6", 0x1122334410101010uL.toLong())
    setRegister("s7", 0x1122334411111111uL.toLong())
    setRegister("fp", 0x102030400f0c0d02uL.toLong())
    setRegister("gp", 0x010203045a6a7a8auL.toLong())
    setRegister("sp", 0x000000007fff4ffcuL.toLong())
    val top = readRegister("sp") and -16L
    setRegister("sp", top)
    val saved = listOf("s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "fp", "gp").associateWith(::readRegister)
    val callerBytes = readBytes(top, 32)
    val protected = listOf(
        traceMemoryStores("endpoints", 16),
        traceMemoryStores("color", 4),
        traceMemoryStores("frame_guard", 4),
        traceMemoryStores("endpoints_guard", 4),
        traceMemoryStores("color_guard", 4),
        traceMemoryStores("count_guard", 4),
    )
    setRegisterToDataAddress("a0", "endpoints")
    setRegisterToDataAddress("a1", "frame")
    setRegister("a2", 0x00000000000b214duL.toLong())
    callFunction("draw_dashed", returnTo = "line_complete")
    expectRegister("v0", 2)
    expectBytes("frame", 77, 33, 11, 0, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 77, 33, 11, 0, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    expectBytes("endpoints", 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 2, 0, 0, 0)
    expectBytes("color", 178, 222, 244, 0)
    expectBytes("line_count", 10, 0, 0, 107)
    expectBytes("frame_guard", 78, 87, 52, 18)
    expectBytes("endpoints_guard", 79, 87, 52, 18)
    expectBytes("color_guard", 64, 87, 52, 18)
    expectBytes("count_guard", 65, 87, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (register, value) -> expectRegister(register, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
    setRegisterToDataAddress("a0", "endpoints")
    setRegisterToDataAddress("a1", "frame")
    setRegister("a2", 0x00000000000b214duL.toLong())
    callFunction("draw_dashed", returnTo = "line_repeat")
    expectRegister("v0", 2)
    expectBytes("frame", 77, 33, 11, 0, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 77, 33, 11, 0, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    expectBytes("endpoints", 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 2, 0, 0, 0)
    expectBytes("color", 178, 222, 244, 0)
    expectBytes("line_count", 10, 0, 0, 107)
    expectBytes("frame_guard", 78, 87, 52, 18)
    expectBytes("endpoints_guard", 79, 87, 52, 18)
    expectBytes("color_guard", 64, 87, 52, 18)
    expectBytes("count_guard", 65, 87, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (register, value) -> expectRegister(register, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
}

case("dashed 7,7 to 7,7", instructionLimit = 10000) {
    setBytes("frame", 0, 0, 0, 90, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    setBytes("endpoints", 7, 0, 0, 0, 7, 0, 0, 0, 7, 0, 0, 0, 7, 0, 0, 0)
    setBytes("color", 171, 219, 243, 0)
    setBytes("line_count", 11, 0, 0, 107)
    setBytes("frame_guard", 45, 87, 52, 18)
    setBytes("endpoints_guard", 46, 87, 52, 18)
    setBytes("color_guard", 47, 87, 52, 18)
    setBytes("count_guard", 32, 87, 52, 18)
    setRegister("s0", 0x112233440b0b0b0buL.toLong())
    setRegister("s1", 0x112233440c0c0c0cuL.toLong())
    setRegister("s2", 0x112233440d0d0d0duL.toLong())
    setRegister("s3", 0x112233440e0e0e0euL.toLong())
    setRegister("s4", 0x112233440f0f0f0fuL.toLong())
    setRegister("s5", 0x1122334410101010uL.toLong())
    setRegister("s6", 0x1122334411111111uL.toLong())
    setRegister("s7", 0x1122334412121212uL.toLong())
    setRegister("fp", 0x102030400e0d0c03uL.toLong())
    setRegister("gp", 0x010203045b6b7b8buL.toLong())
    setRegister("sp", 0x000000007fff3ffcuL.toLong())
    val top = readRegister("sp") and -16L
    setRegister("sp", top)
    val saved = listOf("s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "fp", "gp").associateWith(::readRegister)
    val callerBytes = readBytes(top, 32)
    val protected = listOf(
        traceMemoryStores("endpoints", 16),
        traceMemoryStores("color", 4),
        traceMemoryStores("frame_guard", 4),
        traceMemoryStores("endpoints_guard", 4),
        traceMemoryStores("color_guard", 4),
        traceMemoryStores("count_guard", 4),
    )
    setRegisterToDataAddress("a0", "endpoints")
    setRegisterToDataAddress("a1", "frame")
    setRegister("a2", 0x00000000000c2454uL.toLong())
    callFunction("draw_dashed", returnTo = "line_complete")
    expectRegister("v0", 1)
    expectBytes("frame", 0, 0, 0, 90, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 84, 36, 12, 0)
    expectBytes("endpoints", 7, 0, 0, 0, 7, 0, 0, 0, 7, 0, 0, 0, 7, 0, 0, 0)
    expectBytes("color", 171, 219, 243, 0)
    expectBytes("line_count", 11, 0, 0, 107)
    expectBytes("frame_guard", 45, 87, 52, 18)
    expectBytes("endpoints_guard", 46, 87, 52, 18)
    expectBytes("color_guard", 47, 87, 52, 18)
    expectBytes("count_guard", 32, 87, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (register, value) -> expectRegister(register, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
    setRegisterToDataAddress("a0", "endpoints")
    setRegisterToDataAddress("a1", "frame")
    setRegister("a2", 0x00000000000c2454uL.toLong())
    callFunction("draw_dashed", returnTo = "line_repeat")
    expectRegister("v0", 1)
    expectBytes("frame", 0, 0, 0, 90, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 84, 36, 12, 0)
    expectBytes("endpoints", 7, 0, 0, 0, 7, 0, 0, 0, 7, 0, 0, 0, 7, 0, 0, 0)
    expectBytes("color", 171, 219, 243, 0)
    expectBytes("line_count", 11, 0, 0, 107)
    expectBytes("frame_guard", 45, 87, 52, 18)
    expectBytes("endpoints_guard", 46, 87, 52, 18)
    expectBytes("color_guard", 47, 87, 52, 18)
    expectBytes("count_guard", 32, 87, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (register, value) -> expectRegister(register, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
}

case("dashed 0,0 to 4,1", instructionLimit = 10000) {
    setBytes("frame", 0, 0, 0, 90, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    setBytes("endpoints", 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 1, 0, 0, 0)
    setBytes("color", 164, 216, 242, 0)
    setBytes("line_count", 12, 0, 0, 107)
    setBytes("frame_guard", 12, 87, 52, 18)
    setBytes("endpoints_guard", 13, 87, 52, 18)
    setBytes("color_guard", 14, 87, 52, 18)
    setBytes("count_guard", 15, 87, 52, 18)
    setRegister("s0", 0x112233440c0c0c0cuL.toLong())
    setRegister("s1", 0x112233440d0d0d0duL.toLong())
    setRegister("s2", 0x112233440e0e0e0euL.toLong())
    setRegister("s3", 0x112233440f0f0f0fuL.toLong())
    setRegister("s4", 0x1122334410101010uL.toLong())
    setRegister("s5", 0x1122334411111111uL.toLong())
    setRegister("s6", 0x1122334412121212uL.toLong())
    setRegister("s7", 0x1122334413131313uL.toLong())
    setRegister("fp", 0x10203040090a0b04uL.toLong())
    setRegister("gp", 0x010203045c6c7c8cuL.toLong())
    setRegister("sp", 0x000000007fff2ffcuL.toLong())
    val top = readRegister("sp") and -16L
    setRegister("sp", top)
    val saved = listOf("s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "fp", "gp").associateWith(::readRegister)
    val callerBytes = readBytes(top, 32)
    val protected = listOf(
        traceMemoryStores("endpoints", 16),
        traceMemoryStores("color", 4),
        traceMemoryStores("frame_guard", 4),
        traceMemoryStores("endpoints_guard", 4),
        traceMemoryStores("color_guard", 4),
        traceMemoryStores("count_guard", 4),
    )
    setRegisterToDataAddress("a0", "endpoints")
    setRegisterToDataAddress("a1", "frame")
    setRegister("a2", 0x00000000000d275buL.toLong())
    callFunction("draw_dashed", returnTo = "line_complete")
    expectRegister("v0", 3)
    expectBytes("frame", 91, 39, 13, 0, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 91, 39, 13, 0, 33, 11, 11, 90, 91, 39, 13, 0, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    expectBytes("endpoints", 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 1, 0, 0, 0)
    expectBytes("color", 164, 216, 242, 0)
    expectBytes("line_count", 12, 0, 0, 107)
    expectBytes("frame_guard", 12, 87, 52, 18)
    expectBytes("endpoints_guard", 13, 87, 52, 18)
    expectBytes("color_guard", 14, 87, 52, 18)
    expectBytes("count_guard", 15, 87, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (register, value) -> expectRegister(register, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
    setRegisterToDataAddress("a0", "endpoints")
    setRegisterToDataAddress("a1", "frame")
    setRegister("a2", 0x00000000000d275buL.toLong())
    callFunction("draw_dashed", returnTo = "line_repeat")
    expectRegister("v0", 3)
    expectBytes("frame", 91, 39, 13, 0, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 91, 39, 13, 0, 33, 11, 11, 90, 91, 39, 13, 0, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    expectBytes("endpoints", 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 1, 0, 0, 0)
    expectBytes("color", 164, 216, 242, 0)
    expectBytes("line_count", 12, 0, 0, 107)
    expectBytes("frame_guard", 12, 87, 52, 18)
    expectBytes("endpoints_guard", 13, 87, 52, 18)
    expectBytes("color_guard", 14, 87, 52, 18)
    expectBytes("count_guard", 15, 87, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (register, value) -> expectRegister(register, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
}

case("dashed 4,1 to 0,0", instructionLimit = 10000) {
    setBytes("frame", 0, 0, 0, 90, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    setBytes("endpoints", 4, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    setBytes("color", 157, 213, 241, 0)
    setBytes("line_count", 13, 0, 0, 107)
    setBytes("frame_guard", 235, 87, 52, 18)
    setBytes("endpoints_guard", 236, 87, 52, 18)
    setBytes("color_guard", 237, 87, 52, 18)
    setBytes("count_guard", 238, 87, 52, 18)
    setRegister("s0", 0x112233440d0d0d0duL.toLong())
    setRegister("s1", 0x112233440e0e0e0euL.toLong())
    setRegister("s2", 0x112233440f0f0f0fuL.toLong())
    setRegister("s3", 0x1122334410101010uL.toLong())
    setRegister("s4", 0x1122334411111111uL.toLong())
    setRegister("s5", 0x1122334412121212uL.toLong())
    setRegister("s6", 0x1122334413131313uL.toLong())
    setRegister("s7", 0x1122334414141414uL.toLong())
    setRegister("fp", 0x10203040080b0a05uL.toLong())
    setRegister("gp", 0x010203045d6d7d8duL.toLong())
    setRegister("sp", 0x000000007fff1ffcuL.toLong())
    val top = readRegister("sp") and -16L
    setRegister("sp", top)
    val saved = listOf("s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "fp", "gp").associateWith(::readRegister)
    val callerBytes = readBytes(top, 32)
    val protected = listOf(
        traceMemoryStores("endpoints", 16),
        traceMemoryStores("color", 4),
        traceMemoryStores("frame_guard", 4),
        traceMemoryStores("endpoints_guard", 4),
        traceMemoryStores("color_guard", 4),
        traceMemoryStores("count_guard", 4),
    )
    setRegisterToDataAddress("a0", "endpoints")
    setRegisterToDataAddress("a1", "frame")
    setRegister("a2", 0x00000000000e2a62uL.toLong())
    callFunction("draw_dashed", returnTo = "line_complete")
    expectRegister("v0", 3)
    expectBytes("frame", 98, 42, 14, 0, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 98, 42, 14, 0, 33, 11, 11, 90, 98, 42, 14, 0, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    expectBytes("endpoints", 4, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("color", 157, 213, 241, 0)
    expectBytes("line_count", 13, 0, 0, 107)
    expectBytes("frame_guard", 235, 87, 52, 18)
    expectBytes("endpoints_guard", 236, 87, 52, 18)
    expectBytes("color_guard", 237, 87, 52, 18)
    expectBytes("count_guard", 238, 87, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (register, value) -> expectRegister(register, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
    setRegisterToDataAddress("a0", "endpoints")
    setRegisterToDataAddress("a1", "frame")
    setRegister("a2", 0x00000000000e2a62uL.toLong())
    callFunction("draw_dashed", returnTo = "line_repeat")
    expectRegister("v0", 3)
    expectBytes("frame", 98, 42, 14, 0, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 98, 42, 14, 0, 33, 11, 11, 90, 98, 42, 14, 0, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    expectBytes("endpoints", 4, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("color", 157, 213, 241, 0)
    expectBytes("line_count", 13, 0, 0, 107)
    expectBytes("frame_guard", 235, 87, 52, 18)
    expectBytes("endpoints_guard", 236, 87, 52, 18)
    expectBytes("color_guard", 237, 87, 52, 18)
    expectBytes("count_guard", 238, 87, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (register, value) -> expectRegister(register, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
}

case("dashed 0,0 to 1,4", instructionLimit = 10000) {
    setBytes("frame", 0, 0, 0, 90, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    setBytes("endpoints", 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 4, 0, 0, 0)
    setBytes("color", 150, 210, 240, 0)
    setBytes("line_count", 14, 0, 0, 107)
    setBytes("frame_guard", 202, 87, 52, 18)
    setBytes("endpoints_guard", 203, 87, 52, 18)
    setBytes("color_guard", 204, 87, 52, 18)
    setBytes("count_guard", 205, 87, 52, 18)
    setRegister("s0", 0x112233440e0e0e0euL.toLong())
    setRegister("s1", 0x112233440f0f0f0fuL.toLong())
    setRegister("s2", 0x1122334410101010uL.toLong())
    setRegister("s3", 0x1122334411111111uL.toLong())
    setRegister("s4", 0x1122334412121212uL.toLong())
    setRegister("s5", 0x1122334413131313uL.toLong())
    setRegister("s6", 0x1122334414141414uL.toLong())
    setRegister("s7", 0x1122334415151515uL.toLong())
    setRegister("fp", 0x102030400b080906uL.toLong())
    setRegister("gp", 0x010203045e6e7e8euL.toLong())
    setRegister("sp", 0x000000007fff0ffcuL.toLong())
    val top = readRegister("sp") and -16L
    setRegister("sp", top)
    val saved = listOf("s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "fp", "gp").associateWith(::readRegister)
    val callerBytes = readBytes(top, 32)
    val protected = listOf(
        traceMemoryStores("endpoints", 16),
        traceMemoryStores("color", 4),
        traceMemoryStores("frame_guard", 4),
        traceMemoryStores("endpoints_guard", 4),
        traceMemoryStores("color_guard", 4),
        traceMemoryStores("count_guard", 4),
    )
    setRegisterToDataAddress("a0", "endpoints")
    setRegisterToDataAddress("a1", "frame")
    setRegister("a2", 0x00000000000f2d69uL.toLong())
    callFunction("draw_dashed", returnTo = "line_complete")
    expectRegister("v0", 3)
    expectBytes("frame", 105, 45, 15, 0, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 105, 45, 15, 0, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 105, 45, 15, 0, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    expectBytes("endpoints", 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 4, 0, 0, 0)
    expectBytes("color", 150, 210, 240, 0)
    expectBytes("line_count", 14, 0, 0, 107)
    expectBytes("frame_guard", 202, 87, 52, 18)
    expectBytes("endpoints_guard", 203, 87, 52, 18)
    expectBytes("color_guard", 204, 87, 52, 18)
    expectBytes("count_guard", 205, 87, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (register, value) -> expectRegister(register, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
    setRegisterToDataAddress("a0", "endpoints")
    setRegisterToDataAddress("a1", "frame")
    setRegister("a2", 0x00000000000f2d69uL.toLong())
    callFunction("draw_dashed", returnTo = "line_repeat")
    expectRegister("v0", 3)
    expectBytes("frame", 105, 45, 15, 0, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 105, 45, 15, 0, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 105, 45, 15, 0, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    expectBytes("endpoints", 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 4, 0, 0, 0)
    expectBytes("color", 150, 210, 240, 0)
    expectBytes("line_count", 14, 0, 0, 107)
    expectBytes("frame_guard", 202, 87, 52, 18)
    expectBytes("endpoints_guard", 203, 87, 52, 18)
    expectBytes("color_guard", 204, 87, 52, 18)
    expectBytes("count_guard", 205, 87, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (register, value) -> expectRegister(register, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
}

case("dashed 1,4 to 0,0", instructionLimit = 10000) {
    setBytes("frame", 0, 0, 0, 90, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 51, 17, 17, 90, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 99, 33, 33, 90, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    setBytes("endpoints", 1, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    setBytes("color", 143, 207, 239, 0)
    setBytes("line_count", 15, 0, 0, 107)
    setBytes("frame_guard", 169, 87, 52, 18)
    setBytes("endpoints_guard", 170, 87, 52, 18)
    setBytes("color_guard", 171, 87, 52, 18)
    setBytes("count_guard", 172, 87, 52, 18)
    setRegister("s0", 0x112233440f0f0f0fuL.toLong())
    setRegister("s1", 0x1122334410101010uL.toLong())
    setRegister("s2", 0x1122334411111111uL.toLong())
    setRegister("s3", 0x1122334412121212uL.toLong())
    setRegister("s4", 0x1122334413131313uL.toLong())
    setRegister("s5", 0x1122334414141414uL.toLong())
    setRegister("s6", 0x1122334415151515uL.toLong())
    setRegister("s7", 0x1122334416161616uL.toLong())
    setRegister("fp", 0x102030400a090807uL.toLong())
    setRegister("gp", 0x010203045f6f7f8fuL.toLong())
    setRegister("sp", 0x000000007ffefffcuL.toLong())
    val top = readRegister("sp") and -16L
    setRegister("sp", top)
    val saved = listOf("s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "fp", "gp").associateWith(::readRegister)
    val callerBytes = readBytes(top, 32)
    val protected = listOf(
        traceMemoryStores("endpoints", 16),
        traceMemoryStores("color", 4),
        traceMemoryStores("frame_guard", 4),
        traceMemoryStores("endpoints_guard", 4),
        traceMemoryStores("color_guard", 4),
        traceMemoryStores("count_guard", 4),
    )
    setRegisterToDataAddress("a0", "endpoints")
    setRegisterToDataAddress("a1", "frame")
    setRegister("a2", 0x0000000000103070uL.toLong())
    callFunction("draw_dashed", returnTo = "line_complete")
    expectRegister("v0", 3)
    expectBytes("frame", 112, 48, 16, 0, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 112, 48, 16, 0, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 112, 48, 16, 0, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    expectBytes("endpoints", 1, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("color", 143, 207, 239, 0)
    expectBytes("line_count", 15, 0, 0, 107)
    expectBytes("frame_guard", 169, 87, 52, 18)
    expectBytes("endpoints_guard", 170, 87, 52, 18)
    expectBytes("color_guard", 171, 87, 52, 18)
    expectBytes("count_guard", 172, 87, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (register, value) -> expectRegister(register, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
    setRegisterToDataAddress("a0", "endpoints")
    setRegisterToDataAddress("a1", "frame")
    setRegister("a2", 0x0000000000103070uL.toLong())
    callFunction("draw_dashed", returnTo = "line_repeat")
    expectRegister("v0", 3)
    expectBytes("frame", 112, 48, 16, 0, 3, 1, 1, 90, 6, 2, 2, 90, 9, 3, 3, 90, 12, 4, 4, 90, 15, 5, 5, 90, 18, 6, 6, 90, 21, 7, 7, 90, 24, 8, 8, 90, 27, 9, 9, 90, 30, 10, 10, 90, 33, 11, 11, 90, 36, 12, 12, 90, 39, 13, 13, 90, 42, 14, 14, 90, 45, 15, 15, 90, 48, 16, 16, 90, 112, 48, 16, 0, 54, 18, 18, 90, 57, 19, 19, 90, 60, 20, 20, 90, 63, 21, 21, 90, 66, 22, 22, 90, 69, 23, 23, 90, 72, 24, 24, 90, 75, 25, 25, 90, 78, 26, 26, 90, 81, 27, 27, 90, 84, 28, 28, 90, 87, 29, 29, 90, 90, 30, 30, 90, 93, 31, 31, 90, 96, 32, 32, 90, 112, 48, 16, 0, 102, 34, 34, 90, 105, 35, 35, 90, 108, 36, 36, 90, 111, 37, 37, 90, 114, 38, 38, 90, 117, 39, 39, 90, 120, 40, 40, 90, 123, 41, 41, 90, 126, 42, 42, 90, 129, 43, 43, 90, 132, 44, 44, 90, 135, 45, 45, 90, 138, 46, 46, 90, 141, 47, 47, 90, 144, 48, 48, 90, 147, 49, 49, 90, 150, 50, 50, 90, 153, 51, 51, 90, 156, 52, 52, 90, 159, 53, 53, 90, 162, 54, 54, 90, 165, 55, 55, 90, 168, 56, 56, 90, 171, 57, 57, 90, 174, 58, 58, 90, 177, 59, 59, 90, 180, 60, 60, 90, 183, 61, 61, 90, 186, 62, 62, 90, 189, 63, 63, 90)
    expectBytes("endpoints", 1, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("color", 143, 207, 239, 0)
    expectBytes("line_count", 15, 0, 0, 107)
    expectBytes("frame_guard", 169, 87, 52, 18)
    expectBytes("endpoints_guard", 170, 87, 52, 18)
    expectBytes("color_guard", 171, 87, 52, 18)
    expectBytes("count_guard", 172, 87, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (register, value) -> expectRegister(register, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
}
