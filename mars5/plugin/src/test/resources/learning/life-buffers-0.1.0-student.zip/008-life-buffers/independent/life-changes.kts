// Generated public Life checks; regenerate with tools/life_lesson_cases.py.
// Setup word byte strings target the book little-endian environment.

case("empty A to B", instructionLimit = 50000) {
    setBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    setBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 32, 63, 94, 125, 156, 187, 218, 0, 0, 249, 25, 56, 87, 118, 149, 180, 211, 0, 0, 242, 18, 49, 80, 111, 142, 173, 204, 0, 0, 235, 11, 42, 73, 104, 135, 166, 197, 0, 0, 228, 4, 35, 66, 97, 128, 159, 190, 0, 0, 221, 252, 28, 59, 90, 121, 152, 183, 0, 0, 214, 245, 21, 52, 83, 114, 145, 176, 0, 0, 207, 238, 14, 45, 76, 107, 138, 169, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    setBytes("frame_guard", 120, 86, 52, 18)
    setBytes("seed_guard", 121, 86, 52, 18)
    setBytes("board_a_guard", 122, 86, 52, 18)
    setBytes("board_b_guard", 123, 86, 52, 18)
    setBytes("generations_guard", 124, 86, 52, 18)
    setBytes("generation_guard", 125, 86, 52, 18)
    setRegister("s0", 0x1122334400000000uL.toLong())
    setRegister("s1", 0x1122334401010101uL.toLong())
    setRegister("s2", 0x1122334402020202uL.toLong())
    setRegister("s3", 0x1122334403030303uL.toLong())
    setRegister("s4", 0x1122334404040404uL.toLong())
    setRegister("s5", 0x1122334405050505uL.toLong())
    setRegister("s6", 0x1122334406060606uL.toLong())
    setRegister("s7", 0x1122334407070707uL.toLong())
    setRegister("fp", 0x1020304005060708uL.toLong())
    setRegister("gp", 0x0102030450607080uL.toLong())
    setRegister("sp", 0x000000007fffeffcuL.toLong())
    val top = readRegister("sp") and -16L
    setRegister("sp", top)
    val saved = listOf("s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "fp", "gp").associateWith(::readRegister)
    val callerBytes = readBytes(top, 32)
    val protected = listOf(
        traceMemoryStores("board_a", 100, offset = 0),
        traceMemoryStores("frame_guard", 4, offset = 0),
        traceMemoryStores("seed_guard", 4, offset = 0),
        traceMemoryStores("board_a_guard", 4, offset = 0),
        traceMemoryStores("board_b_guard", 4, offset = 0),
        traceMemoryStores("generations_guard", 4, offset = 0),
        traceMemoryStores("generation_guard", 4, offset = 0),
        traceMemoryStores("board_b", 10, offset = 0),
        traceMemoryStores("board_b", 10, offset = 90),
        traceMemoryStores("board_b", 1, offset = 10),
        traceMemoryStores("board_b", 1, offset = 19),
        traceMemoryStores("board_b", 1, offset = 20),
        traceMemoryStores("board_b", 1, offset = 29),
        traceMemoryStores("board_b", 1, offset = 30),
        traceMemoryStores("board_b", 1, offset = 39),
        traceMemoryStores("board_b", 1, offset = 40),
        traceMemoryStores("board_b", 1, offset = 49),
        traceMemoryStores("board_b", 1, offset = 50),
        traceMemoryStores("board_b", 1, offset = 59),
        traceMemoryStores("board_b", 1, offset = 60),
        traceMemoryStores("board_b", 1, offset = 69),
        traceMemoryStores("board_b", 1, offset = 70),
        traceMemoryStores("board_b", 1, offset = 79),
        traceMemoryStores("board_b", 1, offset = 80),
        traceMemoryStores("board_b", 1, offset = 89),
    )
    setRegisterToDataAddress("a0", "board_a")
    setRegisterToDataAddress("a1", "board_b")
    callFunction("life_changes", returnTo = "generation_built")
    expectRegister("v0", 0)
    expectBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("frame_guard", 120, 86, 52, 18)
    expectBytes("seed_guard", 121, 86, 52, 18)
    expectBytes("board_a_guard", 122, 86, 52, 18)
    expectBytes("board_b_guard", 123, 86, 52, 18)
    expectBytes("generations_guard", 124, 86, 52, 18)
    expectBytes("generation_guard", 125, 86, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (reg, value) -> expectRegister(reg, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
    setRegisterToDataAddress("a0", "board_a")
    setRegisterToDataAddress("a1", "board_b")
    callFunction("life_changes", returnTo = "life_done")
    expectRegister("v0", 0)
    expectBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("frame_guard", 120, 86, 52, 18)
    expectBytes("seed_guard", 121, 86, 52, 18)
    expectBytes("board_a_guard", 122, 86, 52, 18)
    expectBytes("board_b_guard", 123, 86, 52, 18)
    expectBytes("generations_guard", 124, 86, 52, 18)
    expectBytes("generation_guard", 125, 86, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (reg, value) -> expectRegister(reg, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
}

case("empty B to A", instructionLimit = 50000) {
    setBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    setBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 32, 63, 94, 125, 156, 187, 218, 0, 0, 249, 25, 56, 87, 118, 149, 180, 211, 0, 0, 242, 18, 49, 80, 111, 142, 173, 204, 0, 0, 235, 11, 42, 73, 104, 135, 166, 197, 0, 0, 228, 4, 35, 66, 97, 128, 159, 190, 0, 0, 221, 252, 28, 59, 90, 121, 152, 183, 0, 0, 214, 245, 21, 52, 83, 114, 145, 176, 0, 0, 207, 238, 14, 45, 76, 107, 138, 169, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    setBytes("frame_guard", 120, 70, 52, 18)
    setBytes("seed_guard", 121, 70, 52, 18)
    setBytes("board_a_guard", 122, 70, 52, 18)
    setBytes("board_b_guard", 123, 70, 52, 18)
    setBytes("generations_guard", 124, 70, 52, 18)
    setBytes("generation_guard", 125, 70, 52, 18)
    setRegister("s0", 0x1122334500000001uL.toLong())
    setRegister("s1", 0x1122334501010102uL.toLong())
    setRegister("s2", 0x1122334502020203uL.toLong())
    setRegister("s3", 0x1122334503030304uL.toLong())
    setRegister("s4", 0x1122334504040405uL.toLong())
    setRegister("s5", 0x1122334505050506uL.toLong())
    setRegister("s6", 0x1122334506060607uL.toLong())
    setRegister("s7", 0x1122334507070708uL.toLong())
    setRegister("fp", 0x1020304105060709uL.toLong())
    setRegister("gp", 0x0102030550607081uL.toLong())
    setRegister("sp", 0x000000007fffdffcuL.toLong())
    val top = readRegister("sp") and -16L
    setRegister("sp", top)
    val saved = listOf("s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "fp", "gp").associateWith(::readRegister)
    val callerBytes = readBytes(top, 32)
    val protected = listOf(
        traceMemoryStores("board_b", 100, offset = 0),
        traceMemoryStores("frame_guard", 4, offset = 0),
        traceMemoryStores("seed_guard", 4, offset = 0),
        traceMemoryStores("board_a_guard", 4, offset = 0),
        traceMemoryStores("board_b_guard", 4, offset = 0),
        traceMemoryStores("generations_guard", 4, offset = 0),
        traceMemoryStores("generation_guard", 4, offset = 0),
        traceMemoryStores("board_a", 10, offset = 0),
        traceMemoryStores("board_a", 10, offset = 90),
        traceMemoryStores("board_a", 1, offset = 10),
        traceMemoryStores("board_a", 1, offset = 19),
        traceMemoryStores("board_a", 1, offset = 20),
        traceMemoryStores("board_a", 1, offset = 29),
        traceMemoryStores("board_a", 1, offset = 30),
        traceMemoryStores("board_a", 1, offset = 39),
        traceMemoryStores("board_a", 1, offset = 40),
        traceMemoryStores("board_a", 1, offset = 49),
        traceMemoryStores("board_a", 1, offset = 50),
        traceMemoryStores("board_a", 1, offset = 59),
        traceMemoryStores("board_a", 1, offset = 60),
        traceMemoryStores("board_a", 1, offset = 69),
        traceMemoryStores("board_a", 1, offset = 70),
        traceMemoryStores("board_a", 1, offset = 79),
        traceMemoryStores("board_a", 1, offset = 80),
        traceMemoryStores("board_a", 1, offset = 89),
    )
    setRegisterToDataAddress("a0", "board_b")
    setRegisterToDataAddress("a1", "board_a")
    callFunction("life_changes", returnTo = "generation_built")
    expectRegister("v0", 0)
    expectBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("frame_guard", 120, 70, 52, 18)
    expectBytes("seed_guard", 121, 70, 52, 18)
    expectBytes("board_a_guard", 122, 70, 52, 18)
    expectBytes("board_b_guard", 123, 70, 52, 18)
    expectBytes("generations_guard", 124, 70, 52, 18)
    expectBytes("generation_guard", 125, 70, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (reg, value) -> expectRegister(reg, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
    setRegisterToDataAddress("a0", "board_b")
    setRegisterToDataAddress("a1", "board_a")
    callFunction("life_changes", returnTo = "life_done")
    expectRegister("v0", 0)
    expectBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("frame_guard", 120, 70, 52, 18)
    expectBytes("seed_guard", 121, 70, 52, 18)
    expectBytes("board_a_guard", 122, 70, 52, 18)
    expectBytes("board_b_guard", 123, 70, 52, 18)
    expectBytes("generations_guard", 124, 70, 52, 18)
    expectBytes("generation_guard", 125, 70, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (reg, value) -> expectRegister(reg, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
}

case("full A to B", instructionLimit = 50000) {
    setBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    setBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 18, 49, 80, 111, 142, 173, 204, 235, 0, 0, 11, 42, 73, 104, 135, 166, 197, 228, 0, 0, 4, 35, 66, 97, 128, 159, 190, 221, 0, 0, 252, 28, 59, 90, 121, 152, 183, 214, 0, 0, 245, 21, 52, 83, 114, 145, 176, 207, 0, 0, 238, 14, 45, 76, 107, 138, 169, 200, 0, 0, 231, 7, 38, 69, 100, 131, 162, 193, 0, 0, 224, 255, 31, 62, 93, 124, 155, 186, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    setBytes("frame_guard", 103, 86, 52, 18)
    setBytes("seed_guard", 88, 86, 52, 18)
    setBytes("board_a_guard", 89, 86, 52, 18)
    setBytes("board_b_guard", 90, 86, 52, 18)
    setBytes("generations_guard", 91, 86, 52, 18)
    setBytes("generation_guard", 92, 86, 52, 18)
    setRegister("s0", 0x1122334401010101uL.toLong())
    setRegister("s1", 0x1122334402020202uL.toLong())
    setRegister("s2", 0x1122334403030303uL.toLong())
    setRegister("s3", 0x1122334404040404uL.toLong())
    setRegister("s4", 0x1122334405050505uL.toLong())
    setRegister("s5", 0x1122334406060606uL.toLong())
    setRegister("s6", 0x1122334407070707uL.toLong())
    setRegister("s7", 0x1122334408080808uL.toLong())
    setRegister("fp", 0x1020304004070609uL.toLong())
    setRegister("gp", 0x0102030451617181uL.toLong())
    setRegister("sp", 0x000000007fffcffcuL.toLong())
    val top = readRegister("sp") and -16L
    setRegister("sp", top)
    val saved = listOf("s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "fp", "gp").associateWith(::readRegister)
    val callerBytes = readBytes(top, 32)
    val protected = listOf(
        traceMemoryStores("board_a", 100, offset = 0),
        traceMemoryStores("frame_guard", 4, offset = 0),
        traceMemoryStores("seed_guard", 4, offset = 0),
        traceMemoryStores("board_a_guard", 4, offset = 0),
        traceMemoryStores("board_b_guard", 4, offset = 0),
        traceMemoryStores("generations_guard", 4, offset = 0),
        traceMemoryStores("generation_guard", 4, offset = 0),
        traceMemoryStores("board_b", 10, offset = 0),
        traceMemoryStores("board_b", 10, offset = 90),
        traceMemoryStores("board_b", 1, offset = 10),
        traceMemoryStores("board_b", 1, offset = 19),
        traceMemoryStores("board_b", 1, offset = 20),
        traceMemoryStores("board_b", 1, offset = 29),
        traceMemoryStores("board_b", 1, offset = 30),
        traceMemoryStores("board_b", 1, offset = 39),
        traceMemoryStores("board_b", 1, offset = 40),
        traceMemoryStores("board_b", 1, offset = 49),
        traceMemoryStores("board_b", 1, offset = 50),
        traceMemoryStores("board_b", 1, offset = 59),
        traceMemoryStores("board_b", 1, offset = 60),
        traceMemoryStores("board_b", 1, offset = 69),
        traceMemoryStores("board_b", 1, offset = 70),
        traceMemoryStores("board_b", 1, offset = 79),
        traceMemoryStores("board_b", 1, offset = 80),
        traceMemoryStores("board_b", 1, offset = 89),
    )
    setRegisterToDataAddress("a0", "board_a")
    setRegisterToDataAddress("a1", "board_b")
    callFunction("life_changes", returnTo = "generation_built")
    expectRegister("v0", 60)
    expectBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("frame_guard", 103, 86, 52, 18)
    expectBytes("seed_guard", 88, 86, 52, 18)
    expectBytes("board_a_guard", 89, 86, 52, 18)
    expectBytes("board_b_guard", 90, 86, 52, 18)
    expectBytes("generations_guard", 91, 86, 52, 18)
    expectBytes("generation_guard", 92, 86, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (reg, value) -> expectRegister(reg, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
    setRegisterToDataAddress("a0", "board_a")
    setRegisterToDataAddress("a1", "board_b")
    callFunction("life_changes", returnTo = "life_done")
    expectRegister("v0", 60)
    expectBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("frame_guard", 103, 86, 52, 18)
    expectBytes("seed_guard", 88, 86, 52, 18)
    expectBytes("board_a_guard", 89, 86, 52, 18)
    expectBytes("board_b_guard", 90, 86, 52, 18)
    expectBytes("generations_guard", 91, 86, 52, 18)
    expectBytes("generation_guard", 92, 86, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (reg, value) -> expectRegister(reg, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
}

case("full B to A", instructionLimit = 50000) {
    setBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    setBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 18, 49, 80, 111, 142, 173, 204, 235, 0, 0, 11, 42, 73, 104, 135, 166, 197, 228, 0, 0, 4, 35, 66, 97, 128, 159, 190, 221, 0, 0, 252, 28, 59, 90, 121, 152, 183, 214, 0, 0, 245, 21, 52, 83, 114, 145, 176, 207, 0, 0, 238, 14, 45, 76, 107, 138, 169, 200, 0, 0, 231, 7, 38, 69, 100, 131, 162, 193, 0, 0, 224, 255, 31, 62, 93, 124, 155, 186, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    setBytes("frame_guard", 103, 70, 52, 18)
    setBytes("seed_guard", 88, 70, 52, 18)
    setBytes("board_a_guard", 89, 70, 52, 18)
    setBytes("board_b_guard", 90, 70, 52, 18)
    setBytes("generations_guard", 91, 70, 52, 18)
    setBytes("generation_guard", 92, 70, 52, 18)
    setRegister("s0", 0x1122334501010102uL.toLong())
    setRegister("s1", 0x1122334502020203uL.toLong())
    setRegister("s2", 0x1122334503030304uL.toLong())
    setRegister("s3", 0x1122334504040405uL.toLong())
    setRegister("s4", 0x1122334505050506uL.toLong())
    setRegister("s5", 0x1122334506060607uL.toLong())
    setRegister("s6", 0x1122334507070708uL.toLong())
    setRegister("s7", 0x1122334508080809uL.toLong())
    setRegister("fp", 0x102030410407060auL.toLong())
    setRegister("gp", 0x0102030551617182uL.toLong())
    setRegister("sp", 0x000000007fffbffcuL.toLong())
    val top = readRegister("sp") and -16L
    setRegister("sp", top)
    val saved = listOf("s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "fp", "gp").associateWith(::readRegister)
    val callerBytes = readBytes(top, 32)
    val protected = listOf(
        traceMemoryStores("board_b", 100, offset = 0),
        traceMemoryStores("frame_guard", 4, offset = 0),
        traceMemoryStores("seed_guard", 4, offset = 0),
        traceMemoryStores("board_a_guard", 4, offset = 0),
        traceMemoryStores("board_b_guard", 4, offset = 0),
        traceMemoryStores("generations_guard", 4, offset = 0),
        traceMemoryStores("generation_guard", 4, offset = 0),
        traceMemoryStores("board_a", 10, offset = 0),
        traceMemoryStores("board_a", 10, offset = 90),
        traceMemoryStores("board_a", 1, offset = 10),
        traceMemoryStores("board_a", 1, offset = 19),
        traceMemoryStores("board_a", 1, offset = 20),
        traceMemoryStores("board_a", 1, offset = 29),
        traceMemoryStores("board_a", 1, offset = 30),
        traceMemoryStores("board_a", 1, offset = 39),
        traceMemoryStores("board_a", 1, offset = 40),
        traceMemoryStores("board_a", 1, offset = 49),
        traceMemoryStores("board_a", 1, offset = 50),
        traceMemoryStores("board_a", 1, offset = 59),
        traceMemoryStores("board_a", 1, offset = 60),
        traceMemoryStores("board_a", 1, offset = 69),
        traceMemoryStores("board_a", 1, offset = 70),
        traceMemoryStores("board_a", 1, offset = 79),
        traceMemoryStores("board_a", 1, offset = 80),
        traceMemoryStores("board_a", 1, offset = 89),
    )
    setRegisterToDataAddress("a0", "board_b")
    setRegisterToDataAddress("a1", "board_a")
    callFunction("life_changes", returnTo = "generation_built")
    expectRegister("v0", 60)
    expectBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("frame_guard", 103, 70, 52, 18)
    expectBytes("seed_guard", 88, 70, 52, 18)
    expectBytes("board_a_guard", 89, 70, 52, 18)
    expectBytes("board_b_guard", 90, 70, 52, 18)
    expectBytes("generations_guard", 91, 70, 52, 18)
    expectBytes("generation_guard", 92, 70, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (reg, value) -> expectRegister(reg, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
    setRegisterToDataAddress("a0", "board_b")
    setRegisterToDataAddress("a1", "board_a")
    callFunction("life_changes", returnTo = "life_done")
    expectRegister("v0", 60)
    expectBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("frame_guard", 103, 70, 52, 18)
    expectBytes("seed_guard", 88, 70, 52, 18)
    expectBytes("board_a_guard", 89, 70, 52, 18)
    expectBytes("board_b_guard", 90, 70, 52, 18)
    expectBytes("generations_guard", 91, 70, 52, 18)
    expectBytes("generation_guard", 92, 70, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (reg, value) -> expectRegister(reg, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
}

case("oscillator A to B", instructionLimit = 50000) {
    setBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    setBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35, 66, 97, 128, 159, 190, 221, 252, 0, 0, 28, 59, 90, 121, 152, 183, 214, 245, 0, 0, 21, 52, 83, 114, 145, 176, 207, 238, 0, 0, 14, 45, 76, 107, 138, 169, 200, 231, 0, 0, 7, 38, 69, 100, 131, 162, 193, 224, 0, 0, 255, 31, 62, 93, 124, 155, 186, 217, 0, 0, 248, 24, 55, 86, 117, 148, 179, 210, 0, 0, 241, 17, 48, 79, 110, 141, 172, 203, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    setBytes("frame_guard", 70, 86, 52, 18)
    setBytes("seed_guard", 71, 86, 52, 18)
    setBytes("board_a_guard", 56, 86, 52, 18)
    setBytes("board_b_guard", 57, 86, 52, 18)
    setBytes("generations_guard", 58, 86, 52, 18)
    setBytes("generation_guard", 59, 86, 52, 18)
    setRegister("s0", 0x1122334402020202uL.toLong())
    setRegister("s1", 0x1122334403030303uL.toLong())
    setRegister("s2", 0x1122334404040404uL.toLong())
    setRegister("s3", 0x1122334405050505uL.toLong())
    setRegister("s4", 0x1122334406060606uL.toLong())
    setRegister("s5", 0x1122334407070707uL.toLong())
    setRegister("s6", 0x1122334408080808uL.toLong())
    setRegister("s7", 0x1122334409090909uL.toLong())
    setRegister("fp", 0x102030400704050auL.toLong())
    setRegister("gp", 0x0102030452627282uL.toLong())
    setRegister("sp", 0x000000007fffaffcuL.toLong())
    val top = readRegister("sp") and -16L
    setRegister("sp", top)
    val saved = listOf("s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "fp", "gp").associateWith(::readRegister)
    val callerBytes = readBytes(top, 32)
    val protected = listOf(
        traceMemoryStores("board_a", 100, offset = 0),
        traceMemoryStores("frame_guard", 4, offset = 0),
        traceMemoryStores("seed_guard", 4, offset = 0),
        traceMemoryStores("board_a_guard", 4, offset = 0),
        traceMemoryStores("board_b_guard", 4, offset = 0),
        traceMemoryStores("generations_guard", 4, offset = 0),
        traceMemoryStores("generation_guard", 4, offset = 0),
        traceMemoryStores("board_b", 10, offset = 0),
        traceMemoryStores("board_b", 10, offset = 90),
        traceMemoryStores("board_b", 1, offset = 10),
        traceMemoryStores("board_b", 1, offset = 19),
        traceMemoryStores("board_b", 1, offset = 20),
        traceMemoryStores("board_b", 1, offset = 29),
        traceMemoryStores("board_b", 1, offset = 30),
        traceMemoryStores("board_b", 1, offset = 39),
        traceMemoryStores("board_b", 1, offset = 40),
        traceMemoryStores("board_b", 1, offset = 49),
        traceMemoryStores("board_b", 1, offset = 50),
        traceMemoryStores("board_b", 1, offset = 59),
        traceMemoryStores("board_b", 1, offset = 60),
        traceMemoryStores("board_b", 1, offset = 69),
        traceMemoryStores("board_b", 1, offset = 70),
        traceMemoryStores("board_b", 1, offset = 79),
        traceMemoryStores("board_b", 1, offset = 80),
        traceMemoryStores("board_b", 1, offset = 89),
    )
    setRegisterToDataAddress("a0", "board_a")
    setRegisterToDataAddress("a1", "board_b")
    callFunction("life_changes", returnTo = "generation_built")
    expectRegister("v0", 4)
    expectBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("frame_guard", 70, 86, 52, 18)
    expectBytes("seed_guard", 71, 86, 52, 18)
    expectBytes("board_a_guard", 56, 86, 52, 18)
    expectBytes("board_b_guard", 57, 86, 52, 18)
    expectBytes("generations_guard", 58, 86, 52, 18)
    expectBytes("generation_guard", 59, 86, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (reg, value) -> expectRegister(reg, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
    setRegisterToDataAddress("a0", "board_a")
    setRegisterToDataAddress("a1", "board_b")
    callFunction("life_changes", returnTo = "life_done")
    expectRegister("v0", 4)
    expectBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("frame_guard", 70, 86, 52, 18)
    expectBytes("seed_guard", 71, 86, 52, 18)
    expectBytes("board_a_guard", 56, 86, 52, 18)
    expectBytes("board_b_guard", 57, 86, 52, 18)
    expectBytes("generations_guard", 58, 86, 52, 18)
    expectBytes("generation_guard", 59, 86, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (reg, value) -> expectRegister(reg, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
}

case("oscillator B to A", instructionLimit = 50000) {
    setBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    setBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35, 66, 97, 128, 159, 190, 221, 252, 0, 0, 28, 59, 90, 121, 152, 183, 214, 245, 0, 0, 21, 52, 83, 114, 145, 176, 207, 238, 0, 0, 14, 45, 76, 107, 138, 169, 200, 231, 0, 0, 7, 38, 69, 100, 131, 162, 193, 224, 0, 0, 255, 31, 62, 93, 124, 155, 186, 217, 0, 0, 248, 24, 55, 86, 117, 148, 179, 210, 0, 0, 241, 17, 48, 79, 110, 141, 172, 203, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    setBytes("frame_guard", 70, 70, 52, 18)
    setBytes("seed_guard", 71, 70, 52, 18)
    setBytes("board_a_guard", 56, 70, 52, 18)
    setBytes("board_b_guard", 57, 70, 52, 18)
    setBytes("generations_guard", 58, 70, 52, 18)
    setBytes("generation_guard", 59, 70, 52, 18)
    setRegister("s0", 0x1122334502020203uL.toLong())
    setRegister("s1", 0x1122334503030304uL.toLong())
    setRegister("s2", 0x1122334504040405uL.toLong())
    setRegister("s3", 0x1122334505050506uL.toLong())
    setRegister("s4", 0x1122334506060607uL.toLong())
    setRegister("s5", 0x1122334507070708uL.toLong())
    setRegister("s6", 0x1122334508080809uL.toLong())
    setRegister("s7", 0x112233450909090auL.toLong())
    setRegister("fp", 0x102030410704050buL.toLong())
    setRegister("gp", 0x0102030552627283uL.toLong())
    setRegister("sp", 0x000000007fff9ffcuL.toLong())
    val top = readRegister("sp") and -16L
    setRegister("sp", top)
    val saved = listOf("s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "fp", "gp").associateWith(::readRegister)
    val callerBytes = readBytes(top, 32)
    val protected = listOf(
        traceMemoryStores("board_b", 100, offset = 0),
        traceMemoryStores("frame_guard", 4, offset = 0),
        traceMemoryStores("seed_guard", 4, offset = 0),
        traceMemoryStores("board_a_guard", 4, offset = 0),
        traceMemoryStores("board_b_guard", 4, offset = 0),
        traceMemoryStores("generations_guard", 4, offset = 0),
        traceMemoryStores("generation_guard", 4, offset = 0),
        traceMemoryStores("board_a", 10, offset = 0),
        traceMemoryStores("board_a", 10, offset = 90),
        traceMemoryStores("board_a", 1, offset = 10),
        traceMemoryStores("board_a", 1, offset = 19),
        traceMemoryStores("board_a", 1, offset = 20),
        traceMemoryStores("board_a", 1, offset = 29),
        traceMemoryStores("board_a", 1, offset = 30),
        traceMemoryStores("board_a", 1, offset = 39),
        traceMemoryStores("board_a", 1, offset = 40),
        traceMemoryStores("board_a", 1, offset = 49),
        traceMemoryStores("board_a", 1, offset = 50),
        traceMemoryStores("board_a", 1, offset = 59),
        traceMemoryStores("board_a", 1, offset = 60),
        traceMemoryStores("board_a", 1, offset = 69),
        traceMemoryStores("board_a", 1, offset = 70),
        traceMemoryStores("board_a", 1, offset = 79),
        traceMemoryStores("board_a", 1, offset = 80),
        traceMemoryStores("board_a", 1, offset = 89),
    )
    setRegisterToDataAddress("a0", "board_b")
    setRegisterToDataAddress("a1", "board_a")
    callFunction("life_changes", returnTo = "generation_built")
    expectRegister("v0", 4)
    expectBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("frame_guard", 70, 70, 52, 18)
    expectBytes("seed_guard", 71, 70, 52, 18)
    expectBytes("board_a_guard", 56, 70, 52, 18)
    expectBytes("board_b_guard", 57, 70, 52, 18)
    expectBytes("generations_guard", 58, 70, 52, 18)
    expectBytes("generation_guard", 59, 70, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (reg, value) -> expectRegister(reg, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
    setRegisterToDataAddress("a0", "board_b")
    setRegisterToDataAddress("a1", "board_a")
    callFunction("life_changes", returnTo = "life_done")
    expectRegister("v0", 4)
    expectBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("frame_guard", 70, 70, 52, 18)
    expectBytes("seed_guard", 71, 70, 52, 18)
    expectBytes("board_a_guard", 56, 70, 52, 18)
    expectBytes("board_b_guard", 57, 70, 52, 18)
    expectBytes("generations_guard", 58, 70, 52, 18)
    expectBytes("generation_guard", 59, 70, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (reg, value) -> expectRegister(reg, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
}

case("stable block A to B", instructionLimit = 50000) {
    setBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    setBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 52, 83, 114, 145, 176, 207, 238, 14, 0, 0, 45, 76, 107, 138, 169, 200, 231, 7, 0, 0, 38, 69, 100, 131, 162, 193, 224, 255, 0, 0, 31, 62, 93, 124, 155, 186, 217, 248, 0, 0, 24, 55, 86, 117, 148, 179, 210, 241, 0, 0, 17, 48, 79, 110, 141, 172, 203, 234, 0, 0, 10, 41, 72, 103, 134, 165, 196, 227, 0, 0, 3, 34, 65, 96, 127, 158, 189, 220, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    setBytes("frame_guard", 37, 86, 52, 18)
    setBytes("seed_guard", 38, 86, 52, 18)
    setBytes("board_a_guard", 39, 86, 52, 18)
    setBytes("board_b_guard", 24, 86, 52, 18)
    setBytes("generations_guard", 25, 86, 52, 18)
    setBytes("generation_guard", 26, 86, 52, 18)
    setRegister("s0", 0x1122334403030303uL.toLong())
    setRegister("s1", 0x1122334404040404uL.toLong())
    setRegister("s2", 0x1122334405050505uL.toLong())
    setRegister("s3", 0x1122334406060606uL.toLong())
    setRegister("s4", 0x1122334407070707uL.toLong())
    setRegister("s5", 0x1122334408080808uL.toLong())
    setRegister("s6", 0x1122334409090909uL.toLong())
    setRegister("s7", 0x112233440a0a0a0auL.toLong())
    setRegister("fp", 0x102030400605040buL.toLong())
    setRegister("gp", 0x0102030453637383uL.toLong())
    setRegister("sp", 0x000000007fff8ffcuL.toLong())
    val top = readRegister("sp") and -16L
    setRegister("sp", top)
    val saved = listOf("s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "fp", "gp").associateWith(::readRegister)
    val callerBytes = readBytes(top, 32)
    val protected = listOf(
        traceMemoryStores("board_a", 100, offset = 0),
        traceMemoryStores("frame_guard", 4, offset = 0),
        traceMemoryStores("seed_guard", 4, offset = 0),
        traceMemoryStores("board_a_guard", 4, offset = 0),
        traceMemoryStores("board_b_guard", 4, offset = 0),
        traceMemoryStores("generations_guard", 4, offset = 0),
        traceMemoryStores("generation_guard", 4, offset = 0),
        traceMemoryStores("board_b", 10, offset = 0),
        traceMemoryStores("board_b", 10, offset = 90),
        traceMemoryStores("board_b", 1, offset = 10),
        traceMemoryStores("board_b", 1, offset = 19),
        traceMemoryStores("board_b", 1, offset = 20),
        traceMemoryStores("board_b", 1, offset = 29),
        traceMemoryStores("board_b", 1, offset = 30),
        traceMemoryStores("board_b", 1, offset = 39),
        traceMemoryStores("board_b", 1, offset = 40),
        traceMemoryStores("board_b", 1, offset = 49),
        traceMemoryStores("board_b", 1, offset = 50),
        traceMemoryStores("board_b", 1, offset = 59),
        traceMemoryStores("board_b", 1, offset = 60),
        traceMemoryStores("board_b", 1, offset = 69),
        traceMemoryStores("board_b", 1, offset = 70),
        traceMemoryStores("board_b", 1, offset = 79),
        traceMemoryStores("board_b", 1, offset = 80),
        traceMemoryStores("board_b", 1, offset = 89),
    )
    setRegisterToDataAddress("a0", "board_a")
    setRegisterToDataAddress("a1", "board_b")
    callFunction("life_changes", returnTo = "generation_built")
    expectRegister("v0", 0)
    expectBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("frame_guard", 37, 86, 52, 18)
    expectBytes("seed_guard", 38, 86, 52, 18)
    expectBytes("board_a_guard", 39, 86, 52, 18)
    expectBytes("board_b_guard", 24, 86, 52, 18)
    expectBytes("generations_guard", 25, 86, 52, 18)
    expectBytes("generation_guard", 26, 86, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (reg, value) -> expectRegister(reg, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
    setRegisterToDataAddress("a0", "board_a")
    setRegisterToDataAddress("a1", "board_b")
    callFunction("life_changes", returnTo = "life_done")
    expectRegister("v0", 0)
    expectBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("frame_guard", 37, 86, 52, 18)
    expectBytes("seed_guard", 38, 86, 52, 18)
    expectBytes("board_a_guard", 39, 86, 52, 18)
    expectBytes("board_b_guard", 24, 86, 52, 18)
    expectBytes("generations_guard", 25, 86, 52, 18)
    expectBytes("generation_guard", 26, 86, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (reg, value) -> expectRegister(reg, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
}

case("stable block B to A", instructionLimit = 50000) {
    setBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    setBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 52, 83, 114, 145, 176, 207, 238, 14, 0, 0, 45, 76, 107, 138, 169, 200, 231, 7, 0, 0, 38, 69, 100, 131, 162, 193, 224, 255, 0, 0, 31, 62, 93, 124, 155, 186, 217, 248, 0, 0, 24, 55, 86, 117, 148, 179, 210, 241, 0, 0, 17, 48, 79, 110, 141, 172, 203, 234, 0, 0, 10, 41, 72, 103, 134, 165, 196, 227, 0, 0, 3, 34, 65, 96, 127, 158, 189, 220, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    setBytes("frame_guard", 37, 70, 52, 18)
    setBytes("seed_guard", 38, 70, 52, 18)
    setBytes("board_a_guard", 39, 70, 52, 18)
    setBytes("board_b_guard", 24, 70, 52, 18)
    setBytes("generations_guard", 25, 70, 52, 18)
    setBytes("generation_guard", 26, 70, 52, 18)
    setRegister("s0", 0x1122334503030304uL.toLong())
    setRegister("s1", 0x1122334504040405uL.toLong())
    setRegister("s2", 0x1122334505050506uL.toLong())
    setRegister("s3", 0x1122334506060607uL.toLong())
    setRegister("s4", 0x1122334507070708uL.toLong())
    setRegister("s5", 0x1122334508080809uL.toLong())
    setRegister("s6", 0x112233450909090auL.toLong())
    setRegister("s7", 0x112233450a0a0a0buL.toLong())
    setRegister("fp", 0x102030410605040cuL.toLong())
    setRegister("gp", 0x0102030553637384uL.toLong())
    setRegister("sp", 0x000000007fff7ffcuL.toLong())
    val top = readRegister("sp") and -16L
    setRegister("sp", top)
    val saved = listOf("s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "fp", "gp").associateWith(::readRegister)
    val callerBytes = readBytes(top, 32)
    val protected = listOf(
        traceMemoryStores("board_b", 100, offset = 0),
        traceMemoryStores("frame_guard", 4, offset = 0),
        traceMemoryStores("seed_guard", 4, offset = 0),
        traceMemoryStores("board_a_guard", 4, offset = 0),
        traceMemoryStores("board_b_guard", 4, offset = 0),
        traceMemoryStores("generations_guard", 4, offset = 0),
        traceMemoryStores("generation_guard", 4, offset = 0),
        traceMemoryStores("board_a", 10, offset = 0),
        traceMemoryStores("board_a", 10, offset = 90),
        traceMemoryStores("board_a", 1, offset = 10),
        traceMemoryStores("board_a", 1, offset = 19),
        traceMemoryStores("board_a", 1, offset = 20),
        traceMemoryStores("board_a", 1, offset = 29),
        traceMemoryStores("board_a", 1, offset = 30),
        traceMemoryStores("board_a", 1, offset = 39),
        traceMemoryStores("board_a", 1, offset = 40),
        traceMemoryStores("board_a", 1, offset = 49),
        traceMemoryStores("board_a", 1, offset = 50),
        traceMemoryStores("board_a", 1, offset = 59),
        traceMemoryStores("board_a", 1, offset = 60),
        traceMemoryStores("board_a", 1, offset = 69),
        traceMemoryStores("board_a", 1, offset = 70),
        traceMemoryStores("board_a", 1, offset = 79),
        traceMemoryStores("board_a", 1, offset = 80),
        traceMemoryStores("board_a", 1, offset = 89),
    )
    setRegisterToDataAddress("a0", "board_b")
    setRegisterToDataAddress("a1", "board_a")
    callFunction("life_changes", returnTo = "generation_built")
    expectRegister("v0", 0)
    expectBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("frame_guard", 37, 70, 52, 18)
    expectBytes("seed_guard", 38, 70, 52, 18)
    expectBytes("board_a_guard", 39, 70, 52, 18)
    expectBytes("board_b_guard", 24, 70, 52, 18)
    expectBytes("generations_guard", 25, 70, 52, 18)
    expectBytes("generation_guard", 26, 70, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (reg, value) -> expectRegister(reg, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
    setRegisterToDataAddress("a0", "board_b")
    setRegisterToDataAddress("a1", "board_a")
    callFunction("life_changes", returnTo = "life_done")
    expectRegister("v0", 0)
    expectBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("frame_guard", 37, 70, 52, 18)
    expectBytes("seed_guard", 38, 70, 52, 18)
    expectBytes("board_a_guard", 39, 70, 52, 18)
    expectBytes("board_b_guard", 24, 70, 52, 18)
    expectBytes("generations_guard", 25, 70, 52, 18)
    expectBytes("generation_guard", 26, 70, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (reg, value) -> expectRegister(reg, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
}

case("upper-left edge A to B", instructionLimit = 50000) {
    setBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    setBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 69, 100, 131, 162, 193, 224, 255, 31, 0, 0, 62, 93, 124, 155, 186, 217, 248, 24, 0, 0, 55, 86, 117, 148, 179, 210, 241, 17, 0, 0, 48, 79, 110, 141, 172, 203, 234, 10, 0, 0, 41, 72, 103, 134, 165, 196, 227, 3, 0, 0, 34, 65, 96, 127, 158, 189, 220, 251, 0, 0, 27, 58, 89, 120, 151, 182, 213, 244, 0, 0, 20, 51, 82, 113, 144, 175, 206, 237, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    setBytes("frame_guard", 4, 86, 52, 18)
    setBytes("seed_guard", 5, 86, 52, 18)
    setBytes("board_a_guard", 6, 86, 52, 18)
    setBytes("board_b_guard", 7, 86, 52, 18)
    setBytes("generations_guard", 248, 86, 52, 18)
    setBytes("generation_guard", 249, 86, 52, 18)
    setRegister("s0", 0x1122334404040404uL.toLong())
    setRegister("s1", 0x1122334405050505uL.toLong())
    setRegister("s2", 0x1122334406060606uL.toLong())
    setRegister("s3", 0x1122334407070707uL.toLong())
    setRegister("s4", 0x1122334408080808uL.toLong())
    setRegister("s5", 0x1122334409090909uL.toLong())
    setRegister("s6", 0x112233440a0a0a0auL.toLong())
    setRegister("s7", 0x112233440b0b0b0buL.toLong())
    setRegister("fp", 0x102030400102030cuL.toLong())
    setRegister("gp", 0x0102030454647484uL.toLong())
    setRegister("sp", 0x000000007fff6ffcuL.toLong())
    val top = readRegister("sp") and -16L
    setRegister("sp", top)
    val saved = listOf("s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "fp", "gp").associateWith(::readRegister)
    val callerBytes = readBytes(top, 32)
    val protected = listOf(
        traceMemoryStores("board_a", 100, offset = 0),
        traceMemoryStores("frame_guard", 4, offset = 0),
        traceMemoryStores("seed_guard", 4, offset = 0),
        traceMemoryStores("board_a_guard", 4, offset = 0),
        traceMemoryStores("board_b_guard", 4, offset = 0),
        traceMemoryStores("generations_guard", 4, offset = 0),
        traceMemoryStores("generation_guard", 4, offset = 0),
        traceMemoryStores("board_b", 10, offset = 0),
        traceMemoryStores("board_b", 10, offset = 90),
        traceMemoryStores("board_b", 1, offset = 10),
        traceMemoryStores("board_b", 1, offset = 19),
        traceMemoryStores("board_b", 1, offset = 20),
        traceMemoryStores("board_b", 1, offset = 29),
        traceMemoryStores("board_b", 1, offset = 30),
        traceMemoryStores("board_b", 1, offset = 39),
        traceMemoryStores("board_b", 1, offset = 40),
        traceMemoryStores("board_b", 1, offset = 49),
        traceMemoryStores("board_b", 1, offset = 50),
        traceMemoryStores("board_b", 1, offset = 59),
        traceMemoryStores("board_b", 1, offset = 60),
        traceMemoryStores("board_b", 1, offset = 69),
        traceMemoryStores("board_b", 1, offset = 70),
        traceMemoryStores("board_b", 1, offset = 79),
        traceMemoryStores("board_b", 1, offset = 80),
        traceMemoryStores("board_b", 1, offset = 89),
    )
    setRegisterToDataAddress("a0", "board_a")
    setRegisterToDataAddress("a1", "board_b")
    callFunction("life_changes", returnTo = "generation_built")
    expectRegister("v0", 1)
    expectBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("frame_guard", 4, 86, 52, 18)
    expectBytes("seed_guard", 5, 86, 52, 18)
    expectBytes("board_a_guard", 6, 86, 52, 18)
    expectBytes("board_b_guard", 7, 86, 52, 18)
    expectBytes("generations_guard", 248, 86, 52, 18)
    expectBytes("generation_guard", 249, 86, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (reg, value) -> expectRegister(reg, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
    setRegisterToDataAddress("a0", "board_a")
    setRegisterToDataAddress("a1", "board_b")
    callFunction("life_changes", returnTo = "life_done")
    expectRegister("v0", 1)
    expectBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("frame_guard", 4, 86, 52, 18)
    expectBytes("seed_guard", 5, 86, 52, 18)
    expectBytes("board_a_guard", 6, 86, 52, 18)
    expectBytes("board_b_guard", 7, 86, 52, 18)
    expectBytes("generations_guard", 248, 86, 52, 18)
    expectBytes("generation_guard", 249, 86, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (reg, value) -> expectRegister(reg, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
}

case("upper-left edge B to A", instructionLimit = 50000) {
    setBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    setBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 69, 100, 131, 162, 193, 224, 255, 31, 0, 0, 62, 93, 124, 155, 186, 217, 248, 24, 0, 0, 55, 86, 117, 148, 179, 210, 241, 17, 0, 0, 48, 79, 110, 141, 172, 203, 234, 10, 0, 0, 41, 72, 103, 134, 165, 196, 227, 3, 0, 0, 34, 65, 96, 127, 158, 189, 220, 251, 0, 0, 27, 58, 89, 120, 151, 182, 213, 244, 0, 0, 20, 51, 82, 113, 144, 175, 206, 237, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    setBytes("frame_guard", 4, 70, 52, 18)
    setBytes("seed_guard", 5, 70, 52, 18)
    setBytes("board_a_guard", 6, 70, 52, 18)
    setBytes("board_b_guard", 7, 70, 52, 18)
    setBytes("generations_guard", 248, 70, 52, 18)
    setBytes("generation_guard", 249, 70, 52, 18)
    setRegister("s0", 0x1122334504040405uL.toLong())
    setRegister("s1", 0x1122334505050506uL.toLong())
    setRegister("s2", 0x1122334506060607uL.toLong())
    setRegister("s3", 0x1122334507070708uL.toLong())
    setRegister("s4", 0x1122334508080809uL.toLong())
    setRegister("s5", 0x112233450909090auL.toLong())
    setRegister("s6", 0x112233450a0a0a0buL.toLong())
    setRegister("s7", 0x112233450b0b0b0cuL.toLong())
    setRegister("fp", 0x102030410102030duL.toLong())
    setRegister("gp", 0x0102030554647485uL.toLong())
    setRegister("sp", 0x000000007fff5ffcuL.toLong())
    val top = readRegister("sp") and -16L
    setRegister("sp", top)
    val saved = listOf("s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "fp", "gp").associateWith(::readRegister)
    val callerBytes = readBytes(top, 32)
    val protected = listOf(
        traceMemoryStores("board_b", 100, offset = 0),
        traceMemoryStores("frame_guard", 4, offset = 0),
        traceMemoryStores("seed_guard", 4, offset = 0),
        traceMemoryStores("board_a_guard", 4, offset = 0),
        traceMemoryStores("board_b_guard", 4, offset = 0),
        traceMemoryStores("generations_guard", 4, offset = 0),
        traceMemoryStores("generation_guard", 4, offset = 0),
        traceMemoryStores("board_a", 10, offset = 0),
        traceMemoryStores("board_a", 10, offset = 90),
        traceMemoryStores("board_a", 1, offset = 10),
        traceMemoryStores("board_a", 1, offset = 19),
        traceMemoryStores("board_a", 1, offset = 20),
        traceMemoryStores("board_a", 1, offset = 29),
        traceMemoryStores("board_a", 1, offset = 30),
        traceMemoryStores("board_a", 1, offset = 39),
        traceMemoryStores("board_a", 1, offset = 40),
        traceMemoryStores("board_a", 1, offset = 49),
        traceMemoryStores("board_a", 1, offset = 50),
        traceMemoryStores("board_a", 1, offset = 59),
        traceMemoryStores("board_a", 1, offset = 60),
        traceMemoryStores("board_a", 1, offset = 69),
        traceMemoryStores("board_a", 1, offset = 70),
        traceMemoryStores("board_a", 1, offset = 79),
        traceMemoryStores("board_a", 1, offset = 80),
        traceMemoryStores("board_a", 1, offset = 89),
    )
    setRegisterToDataAddress("a0", "board_b")
    setRegisterToDataAddress("a1", "board_a")
    callFunction("life_changes", returnTo = "generation_built")
    expectRegister("v0", 1)
    expectBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("frame_guard", 4, 70, 52, 18)
    expectBytes("seed_guard", 5, 70, 52, 18)
    expectBytes("board_a_guard", 6, 70, 52, 18)
    expectBytes("board_b_guard", 7, 70, 52, 18)
    expectBytes("generations_guard", 248, 70, 52, 18)
    expectBytes("generation_guard", 249, 70, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (reg, value) -> expectRegister(reg, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
    setRegisterToDataAddress("a0", "board_b")
    setRegisterToDataAddress("a1", "board_a")
    callFunction("life_changes", returnTo = "life_done")
    expectRegister("v0", 1)
    expectBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("frame_guard", 4, 70, 52, 18)
    expectBytes("seed_guard", 5, 70, 52, 18)
    expectBytes("board_a_guard", 6, 70, 52, 18)
    expectBytes("board_b_guard", 7, 70, 52, 18)
    expectBytes("generations_guard", 248, 70, 52, 18)
    expectBytes("generation_guard", 249, 70, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (reg, value) -> expectRegister(reg, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
}

case("separate corners A to B", instructionLimit = 50000) {
    setBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    setBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 86, 117, 148, 179, 210, 241, 17, 48, 0, 0, 79, 110, 141, 172, 203, 234, 10, 41, 0, 0, 72, 103, 134, 165, 196, 227, 3, 34, 0, 0, 65, 96, 127, 158, 189, 220, 251, 27, 0, 0, 58, 89, 120, 151, 182, 213, 244, 20, 0, 0, 51, 82, 113, 144, 175, 206, 237, 13, 0, 0, 44, 75, 106, 137, 168, 199, 230, 6, 0, 0, 37, 68, 99, 130, 161, 192, 223, 254, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    setBytes("frame_guard", 227, 86, 52, 18)
    setBytes("seed_guard", 228, 86, 52, 18)
    setBytes("board_a_guard", 229, 86, 52, 18)
    setBytes("board_b_guard", 230, 86, 52, 18)
    setBytes("generations_guard", 231, 86, 52, 18)
    setBytes("generation_guard", 216, 86, 52, 18)
    setRegister("s0", 0x1122334405050505uL.toLong())
    setRegister("s1", 0x1122334406060606uL.toLong())
    setRegister("s2", 0x1122334407070707uL.toLong())
    setRegister("s3", 0x1122334408080808uL.toLong())
    setRegister("s4", 0x1122334409090909uL.toLong())
    setRegister("s5", 0x112233440a0a0a0auL.toLong())
    setRegister("s6", 0x112233440b0b0b0buL.toLong())
    setRegister("s7", 0x112233440c0c0c0cuL.toLong())
    setRegister("fp", 0x102030400003020duL.toLong())
    setRegister("gp", 0x0102030455657585uL.toLong())
    setRegister("sp", 0x000000007fff4ffcuL.toLong())
    val top = readRegister("sp") and -16L
    setRegister("sp", top)
    val saved = listOf("s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "fp", "gp").associateWith(::readRegister)
    val callerBytes = readBytes(top, 32)
    val protected = listOf(
        traceMemoryStores("board_a", 100, offset = 0),
        traceMemoryStores("frame_guard", 4, offset = 0),
        traceMemoryStores("seed_guard", 4, offset = 0),
        traceMemoryStores("board_a_guard", 4, offset = 0),
        traceMemoryStores("board_b_guard", 4, offset = 0),
        traceMemoryStores("generations_guard", 4, offset = 0),
        traceMemoryStores("generation_guard", 4, offset = 0),
        traceMemoryStores("board_b", 10, offset = 0),
        traceMemoryStores("board_b", 10, offset = 90),
        traceMemoryStores("board_b", 1, offset = 10),
        traceMemoryStores("board_b", 1, offset = 19),
        traceMemoryStores("board_b", 1, offset = 20),
        traceMemoryStores("board_b", 1, offset = 29),
        traceMemoryStores("board_b", 1, offset = 30),
        traceMemoryStores("board_b", 1, offset = 39),
        traceMemoryStores("board_b", 1, offset = 40),
        traceMemoryStores("board_b", 1, offset = 49),
        traceMemoryStores("board_b", 1, offset = 50),
        traceMemoryStores("board_b", 1, offset = 59),
        traceMemoryStores("board_b", 1, offset = 60),
        traceMemoryStores("board_b", 1, offset = 69),
        traceMemoryStores("board_b", 1, offset = 70),
        traceMemoryStores("board_b", 1, offset = 79),
        traceMemoryStores("board_b", 1, offset = 80),
        traceMemoryStores("board_b", 1, offset = 89),
    )
    setRegisterToDataAddress("a0", "board_a")
    setRegisterToDataAddress("a1", "board_b")
    callFunction("life_changes", returnTo = "generation_built")
    expectRegister("v0", 2)
    expectBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("frame_guard", 227, 86, 52, 18)
    expectBytes("seed_guard", 228, 86, 52, 18)
    expectBytes("board_a_guard", 229, 86, 52, 18)
    expectBytes("board_b_guard", 230, 86, 52, 18)
    expectBytes("generations_guard", 231, 86, 52, 18)
    expectBytes("generation_guard", 216, 86, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (reg, value) -> expectRegister(reg, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
    setRegisterToDataAddress("a0", "board_a")
    setRegisterToDataAddress("a1", "board_b")
    callFunction("life_changes", returnTo = "life_done")
    expectRegister("v0", 2)
    expectBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("frame_guard", 227, 86, 52, 18)
    expectBytes("seed_guard", 228, 86, 52, 18)
    expectBytes("board_a_guard", 229, 86, 52, 18)
    expectBytes("board_b_guard", 230, 86, 52, 18)
    expectBytes("generations_guard", 231, 86, 52, 18)
    expectBytes("generation_guard", 216, 86, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (reg, value) -> expectRegister(reg, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
}

case("separate corners B to A", instructionLimit = 50000) {
    setBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    setBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 86, 117, 148, 179, 210, 241, 17, 48, 0, 0, 79, 110, 141, 172, 203, 234, 10, 41, 0, 0, 72, 103, 134, 165, 196, 227, 3, 34, 0, 0, 65, 96, 127, 158, 189, 220, 251, 27, 0, 0, 58, 89, 120, 151, 182, 213, 244, 20, 0, 0, 51, 82, 113, 144, 175, 206, 237, 13, 0, 0, 44, 75, 106, 137, 168, 199, 230, 6, 0, 0, 37, 68, 99, 130, 161, 192, 223, 254, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    setBytes("frame_guard", 227, 70, 52, 18)
    setBytes("seed_guard", 228, 70, 52, 18)
    setBytes("board_a_guard", 229, 70, 52, 18)
    setBytes("board_b_guard", 230, 70, 52, 18)
    setBytes("generations_guard", 231, 70, 52, 18)
    setBytes("generation_guard", 216, 70, 52, 18)
    setRegister("s0", 0x1122334505050506uL.toLong())
    setRegister("s1", 0x1122334506060607uL.toLong())
    setRegister("s2", 0x1122334507070708uL.toLong())
    setRegister("s3", 0x1122334508080809uL.toLong())
    setRegister("s4", 0x112233450909090auL.toLong())
    setRegister("s5", 0x112233450a0a0a0buL.toLong())
    setRegister("s6", 0x112233450b0b0b0cuL.toLong())
    setRegister("s7", 0x112233450c0c0c0duL.toLong())
    setRegister("fp", 0x102030410003020euL.toLong())
    setRegister("gp", 0x0102030555657586uL.toLong())
    setRegister("sp", 0x000000007fff3ffcuL.toLong())
    val top = readRegister("sp") and -16L
    setRegister("sp", top)
    val saved = listOf("s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "fp", "gp").associateWith(::readRegister)
    val callerBytes = readBytes(top, 32)
    val protected = listOf(
        traceMemoryStores("board_b", 100, offset = 0),
        traceMemoryStores("frame_guard", 4, offset = 0),
        traceMemoryStores("seed_guard", 4, offset = 0),
        traceMemoryStores("board_a_guard", 4, offset = 0),
        traceMemoryStores("board_b_guard", 4, offset = 0),
        traceMemoryStores("generations_guard", 4, offset = 0),
        traceMemoryStores("generation_guard", 4, offset = 0),
        traceMemoryStores("board_a", 10, offset = 0),
        traceMemoryStores("board_a", 10, offset = 90),
        traceMemoryStores("board_a", 1, offset = 10),
        traceMemoryStores("board_a", 1, offset = 19),
        traceMemoryStores("board_a", 1, offset = 20),
        traceMemoryStores("board_a", 1, offset = 29),
        traceMemoryStores("board_a", 1, offset = 30),
        traceMemoryStores("board_a", 1, offset = 39),
        traceMemoryStores("board_a", 1, offset = 40),
        traceMemoryStores("board_a", 1, offset = 49),
        traceMemoryStores("board_a", 1, offset = 50),
        traceMemoryStores("board_a", 1, offset = 59),
        traceMemoryStores("board_a", 1, offset = 60),
        traceMemoryStores("board_a", 1, offset = 69),
        traceMemoryStores("board_a", 1, offset = 70),
        traceMemoryStores("board_a", 1, offset = 79),
        traceMemoryStores("board_a", 1, offset = 80),
        traceMemoryStores("board_a", 1, offset = 89),
    )
    setRegisterToDataAddress("a0", "board_b")
    setRegisterToDataAddress("a1", "board_a")
    callFunction("life_changes", returnTo = "generation_built")
    expectRegister("v0", 2)
    expectBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("frame_guard", 227, 70, 52, 18)
    expectBytes("seed_guard", 228, 70, 52, 18)
    expectBytes("board_a_guard", 229, 70, 52, 18)
    expectBytes("board_b_guard", 230, 70, 52, 18)
    expectBytes("generations_guard", 231, 70, 52, 18)
    expectBytes("generation_guard", 216, 70, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (reg, value) -> expectRegister(reg, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
    setRegisterToDataAddress("a0", "board_b")
    setRegisterToDataAddress("a1", "board_a")
    callFunction("life_changes", returnTo = "life_done")
    expectRegister("v0", 2)
    expectBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("frame_guard", 227, 70, 52, 18)
    expectBytes("seed_guard", 228, 70, 52, 18)
    expectBytes("board_a_guard", 229, 70, 52, 18)
    expectBytes("board_b_guard", 230, 70, 52, 18)
    expectBytes("generations_guard", 231, 70, 52, 18)
    expectBytes("generation_guard", 216, 70, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (reg, value) -> expectRegister(reg, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
}

case("asymmetric A to B", instructionLimit = 50000) {
    setBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    setBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 103, 134, 165, 196, 227, 3, 34, 65, 0, 0, 96, 127, 158, 189, 220, 251, 27, 58, 0, 0, 89, 120, 151, 182, 213, 244, 20, 51, 0, 0, 82, 113, 144, 175, 206, 237, 13, 44, 0, 0, 75, 106, 137, 168, 199, 230, 6, 37, 0, 0, 68, 99, 130, 161, 192, 223, 254, 30, 0, 0, 61, 92, 123, 154, 185, 216, 247, 23, 0, 0, 54, 85, 116, 147, 178, 209, 240, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    setBytes("frame_guard", 194, 86, 52, 18)
    setBytes("seed_guard", 195, 86, 52, 18)
    setBytes("board_a_guard", 196, 86, 52, 18)
    setBytes("board_b_guard", 197, 86, 52, 18)
    setBytes("generations_guard", 198, 86, 52, 18)
    setBytes("generation_guard", 199, 86, 52, 18)
    setRegister("s0", 0x1122334406060606uL.toLong())
    setRegister("s1", 0x1122334407070707uL.toLong())
    setRegister("s2", 0x1122334408080808uL.toLong())
    setRegister("s3", 0x1122334409090909uL.toLong())
    setRegister("s4", 0x112233440a0a0a0auL.toLong())
    setRegister("s5", 0x112233440b0b0b0buL.toLong())
    setRegister("s6", 0x112233440c0c0c0cuL.toLong())
    setRegister("s7", 0x112233440d0d0d0duL.toLong())
    setRegister("fp", 0x102030400300010euL.toLong())
    setRegister("gp", 0x0102030456667686uL.toLong())
    setRegister("sp", 0x000000007fff2ffcuL.toLong())
    val top = readRegister("sp") and -16L
    setRegister("sp", top)
    val saved = listOf("s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "fp", "gp").associateWith(::readRegister)
    val callerBytes = readBytes(top, 32)
    val protected = listOf(
        traceMemoryStores("board_a", 100, offset = 0),
        traceMemoryStores("frame_guard", 4, offset = 0),
        traceMemoryStores("seed_guard", 4, offset = 0),
        traceMemoryStores("board_a_guard", 4, offset = 0),
        traceMemoryStores("board_b_guard", 4, offset = 0),
        traceMemoryStores("generations_guard", 4, offset = 0),
        traceMemoryStores("generation_guard", 4, offset = 0),
        traceMemoryStores("board_b", 10, offset = 0),
        traceMemoryStores("board_b", 10, offset = 90),
        traceMemoryStores("board_b", 1, offset = 10),
        traceMemoryStores("board_b", 1, offset = 19),
        traceMemoryStores("board_b", 1, offset = 20),
        traceMemoryStores("board_b", 1, offset = 29),
        traceMemoryStores("board_b", 1, offset = 30),
        traceMemoryStores("board_b", 1, offset = 39),
        traceMemoryStores("board_b", 1, offset = 40),
        traceMemoryStores("board_b", 1, offset = 49),
        traceMemoryStores("board_b", 1, offset = 50),
        traceMemoryStores("board_b", 1, offset = 59),
        traceMemoryStores("board_b", 1, offset = 60),
        traceMemoryStores("board_b", 1, offset = 69),
        traceMemoryStores("board_b", 1, offset = 70),
        traceMemoryStores("board_b", 1, offset = 79),
        traceMemoryStores("board_b", 1, offset = 80),
        traceMemoryStores("board_b", 1, offset = 89),
    )
    setRegisterToDataAddress("a0", "board_a")
    setRegisterToDataAddress("a1", "board_b")
    callFunction("life_changes", returnTo = "generation_built")
    expectRegister("v0", 10)
    expectBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("frame_guard", 194, 86, 52, 18)
    expectBytes("seed_guard", 195, 86, 52, 18)
    expectBytes("board_a_guard", 196, 86, 52, 18)
    expectBytes("board_b_guard", 197, 86, 52, 18)
    expectBytes("generations_guard", 198, 86, 52, 18)
    expectBytes("generation_guard", 199, 86, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (reg, value) -> expectRegister(reg, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
    setRegisterToDataAddress("a0", "board_a")
    setRegisterToDataAddress("a1", "board_b")
    callFunction("life_changes", returnTo = "life_done")
    expectRegister("v0", 10)
    expectBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("frame_guard", 194, 86, 52, 18)
    expectBytes("seed_guard", 195, 86, 52, 18)
    expectBytes("board_a_guard", 196, 86, 52, 18)
    expectBytes("board_b_guard", 197, 86, 52, 18)
    expectBytes("generations_guard", 198, 86, 52, 18)
    expectBytes("generation_guard", 199, 86, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (reg, value) -> expectRegister(reg, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
}

case("asymmetric B to A", instructionLimit = 50000) {
    setBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    setBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 103, 134, 165, 196, 227, 3, 34, 65, 0, 0, 96, 127, 158, 189, 220, 251, 27, 58, 0, 0, 89, 120, 151, 182, 213, 244, 20, 51, 0, 0, 82, 113, 144, 175, 206, 237, 13, 44, 0, 0, 75, 106, 137, 168, 199, 230, 6, 37, 0, 0, 68, 99, 130, 161, 192, 223, 254, 30, 0, 0, 61, 92, 123, 154, 185, 216, 247, 23, 0, 0, 54, 85, 116, 147, 178, 209, 240, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    setBytes("frame_guard", 194, 70, 52, 18)
    setBytes("seed_guard", 195, 70, 52, 18)
    setBytes("board_a_guard", 196, 70, 52, 18)
    setBytes("board_b_guard", 197, 70, 52, 18)
    setBytes("generations_guard", 198, 70, 52, 18)
    setBytes("generation_guard", 199, 70, 52, 18)
    setRegister("s0", 0x1122334506060607uL.toLong())
    setRegister("s1", 0x1122334507070708uL.toLong())
    setRegister("s2", 0x1122334508080809uL.toLong())
    setRegister("s3", 0x112233450909090auL.toLong())
    setRegister("s4", 0x112233450a0a0a0buL.toLong())
    setRegister("s5", 0x112233450b0b0b0cuL.toLong())
    setRegister("s6", 0x112233450c0c0c0duL.toLong())
    setRegister("s7", 0x112233450d0d0d0euL.toLong())
    setRegister("fp", 0x102030410300010fuL.toLong())
    setRegister("gp", 0x0102030556667687uL.toLong())
    setRegister("sp", 0x000000007fff1ffcuL.toLong())
    val top = readRegister("sp") and -16L
    setRegister("sp", top)
    val saved = listOf("s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "fp", "gp").associateWith(::readRegister)
    val callerBytes = readBytes(top, 32)
    val protected = listOf(
        traceMemoryStores("board_b", 100, offset = 0),
        traceMemoryStores("frame_guard", 4, offset = 0),
        traceMemoryStores("seed_guard", 4, offset = 0),
        traceMemoryStores("board_a_guard", 4, offset = 0),
        traceMemoryStores("board_b_guard", 4, offset = 0),
        traceMemoryStores("generations_guard", 4, offset = 0),
        traceMemoryStores("generation_guard", 4, offset = 0),
        traceMemoryStores("board_a", 10, offset = 0),
        traceMemoryStores("board_a", 10, offset = 90),
        traceMemoryStores("board_a", 1, offset = 10),
        traceMemoryStores("board_a", 1, offset = 19),
        traceMemoryStores("board_a", 1, offset = 20),
        traceMemoryStores("board_a", 1, offset = 29),
        traceMemoryStores("board_a", 1, offset = 30),
        traceMemoryStores("board_a", 1, offset = 39),
        traceMemoryStores("board_a", 1, offset = 40),
        traceMemoryStores("board_a", 1, offset = 49),
        traceMemoryStores("board_a", 1, offset = 50),
        traceMemoryStores("board_a", 1, offset = 59),
        traceMemoryStores("board_a", 1, offset = 60),
        traceMemoryStores("board_a", 1, offset = 69),
        traceMemoryStores("board_a", 1, offset = 70),
        traceMemoryStores("board_a", 1, offset = 79),
        traceMemoryStores("board_a", 1, offset = 80),
        traceMemoryStores("board_a", 1, offset = 89),
    )
    setRegisterToDataAddress("a0", "board_b")
    setRegisterToDataAddress("a1", "board_a")
    callFunction("life_changes", returnTo = "generation_built")
    expectRegister("v0", 10)
    expectBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("frame_guard", 194, 70, 52, 18)
    expectBytes("seed_guard", 195, 70, 52, 18)
    expectBytes("board_a_guard", 196, 70, 52, 18)
    expectBytes("board_b_guard", 197, 70, 52, 18)
    expectBytes("generations_guard", 198, 70, 52, 18)
    expectBytes("generation_guard", 199, 70, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (reg, value) -> expectRegister(reg, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
    setRegisterToDataAddress("a0", "board_b")
    setRegisterToDataAddress("a1", "board_a")
    callFunction("life_changes", returnTo = "life_done")
    expectRegister("v0", 10)
    expectBytes("board_b", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("board_a", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    expectBytes("frame_guard", 194, 70, 52, 18)
    expectBytes("seed_guard", 195, 70, 52, 18)
    expectBytes("board_a_guard", 196, 70, 52, 18)
    expectBytes("board_b_guard", 197, 70, 52, 18)
    expectBytes("generations_guard", 198, 70, 52, 18)
    expectBytes("generation_guard", 199, 70, 52, 18)
    protected.forEach { it.expectNone() }
    expectRegister("sp", top)
    saved.forEach { (reg, value) -> expectRegister(reg, value) }
    expectCondition(readBytes(top, 32).contentEquals(callerBytes), "Caller-owned stack bytes changed")
    expectOutput("")
}
